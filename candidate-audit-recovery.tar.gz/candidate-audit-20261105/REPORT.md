# 240 açıq nümunədə namizəd seçiminin araşdırılması

SlothAI-nin `d8a10ec79a498835f1a72655877be47d8e011096` versiyası yoxlandı.
240 cümlədə 247 problemli yer var: 235 tək söz problemi və 12 söz sərhədi problemi.
Nəticələr əvvəlcədən seçilmiş, assistant tərəfindən hazırlanmış inkişaf nümunələrinə
və onların sabit istinadlarına aiddir; ümumi istifadəçi dəqiqliyi ölçülmür.

Əsas nəticə: 235 söz probleminin yalnız 78-i normal tətbiqdə WordLM sıralamasına
çatır. Onların 45-ində düzgün namizəd siyahıda var, 33-ündə yoxdur. Qalan 157 söz
seçimdən əvvəl filtrlərdə dayanır. Sonrakı qaydaların qəbul edilmiş düzgün WordLM
namizədini pozduğu hal tapılmadı.

## WordLM-in real seçim yolu

Saylar cümlə deyil, problemli yerlər üzrədir; bəzi cümlələrdə bir neçə problem var.

| Birinci maneə | Say | Nə baş verir |
| --- | ---: | --- |
| ASCII-dən kənar hərf | 103 | İçində `ə`, `ı`, `ş` və s. olan səhv söz kiçik ASCII söz şərtini keçmir. |
| Böyük hərflə başlayan ASCII giriş | 6 | Məsələn, `Qus` və `Kurratorun` seçimə buraxılmır. |
| Minimum uzunluq | 6 | `de → də` kimi ikihərfli söz minimum üç hərf şərtini keçmir. |
| Girişin düzgün sayılması | 42 | Mövcud lüğət/morfologiya sözü tanıyır, buna görə normal tətbiq sıralamadan əvvəl onu saxlayır. |
| Düzgün namizəd siyahıda yoxdur | 33 | Mövcud lüğət, morfoloji təklif və redaktə generatoru lazım olan formanı vermir. |
| Namizəd var, kontekst sübutu çatmır | 45 | Düzgün forma sıralanır, lakin saxlanmış leksik biqram/triqram sübutu qəbul şərtini ödəmir. |
| Bitişik sözün ayrılması | 12 | Bir token iki sözə çevrilməlidir; tək söz əvəz edən namizəd siyahısı bunu ifadə etmir. |
| **Cəmi** | **247** | **240 ayrı cümlə** |

33 namizəd çatışmazlığının **25-ində düzgün forma WordLM-in 150 000 sözlük
lüğətində və tətbiqin leksik tanıma xidmətində mövcuddur**, lakin seçim siyahısına
ötürülmür. Məsələn, `sureti → surəti` üçün real siyahı `sureti`, `sürət`, `surət`
olur. Siyahını səkkizdən böyütmək bu 33 nümunənin səbəbini həll etmir: mövcud
redaktə generatorunun 24 təklifi arasında da həmin düzgün formalar yoxdur.

Düzgün namizədin olduğu 45 yerdə:

- **31-də düzgün variant ən yüksək birgə balı alır.**
- 14-də başqa namizəd daha yüksək bal alır; burada sıralama da problemi həll etmir.
- 45-in heç birində düzgün variant üçün tələb edilən konkret saxlanmış kontekst
  sübutu yoxdur. Brauzer proyeksiyası 20 000 biqram və 40 000 triqram saxlayır.
  Bu yoxluq tam mənbə korpusunda belə kontekstin heç olmadığı mənasına gəlmir.
- Birinci olan 31 variantdan yalnız **15-i** minimum bal fərqi şərtini də keçir;
  qalan 16-sı kontekst şərti yumşaldılsa belə bal fərqində dayanardı.

Bu rəqəmlər kontekst sübutu şərtini ümumi şəkildə silməyə əsas vermir: burada
yalnız əvvəlcədən səhv olan nümunələr araşdırılıb. Düzgün girişlərdə yanlış
əvəzləmələr ayrıca ölçülməlidir.

## Konkret nümunələr

| Girişdəki söz | Tətbiqin saxladığı variant | İstinad | Təsdiqlənmiş səbəb |
| --- | --- | --- | --- |
| `liiftindən` | `liiftindən` | `liftindən` | `ı/ə` olan giriş ASCII şərtində dayanır. |
| `sərtler` | `sərtlər` | `şərtlər` | Qarışıq Azərbaycan/ASCII yazılışı WordLM seçiminə buraxılmır. |
| `adi` | `adi` | `adı` | Mövcud lüğətdə `adi` tanındığı üçün giriş qorunur. Kontekstdə başqa məna tələb olunur. |
| `sureti` | `sureti` | `surəti` | Düzgün forma model lüğətində var, real namizəd siyahısında yoxdur. |
| `acari` | `acarı` | `açarı` | `novel10k-rsd-0115`: düzgün variant ən yüksək balı və kifayət qədər fərqi alır, kontekst sübutu şərtində rədd edilir. |
| `işarələnirvə` | `işarələnirvə` | `işarələnir və` | Ayrı söz sərhədi qərarı lazımdır. |

`acari` nümunəsində ən yüksək ballar: `açarı = -30.263`, `acari = -36.046`,
`acarı = -37.046`. Bunlar nisbi model/kanal ballarıdır, düzgünlük ehtimalı deyil.

## CharSpell-in ayrıca yoxlanması

Davam edən təlimin **ikinci epoxa checkpoint-i** dəyişdirilmədən kopyalanıb,
yalnız oxuma rejimində yoxlandı. SHA-256:
`7d4338fc926023491d2d2f2c46196f7eb39af8bfad9134793e7ce596ba7e8ae3`.
Checkpoint və təlim kodu dəyişdirilmədi, gradient hesablanmadı və model tətbiqə
qoşulmadı. Mövcud generator maksimum 20 namizəd qaytardı; istinad variantı siyahıya
əlavə edilmədi. Kontekst giriş cümləsindəki iki sol və iki sağ sözdən götürüldü.

| 235 tək söz problemi üzrə nəticə | Say |
| --- | ---: |
| Düzgün variant namizəd siyahısında var | 200 |
| Düzgün variant siyahıda yoxdur | 35 |
| Düzgün variant birinci seçilir | 96 |
| Düzgün variant ilk üçlükdədir | 192 |
| Namizəd var, başqa variant birinci seçilir | 104 |

104 səhv sıralamanın 88-ində giriş sözü saxlanır, 16-sında başqa səhv variant seçilir.
35 çatışmayan formanın hamısı statik 150 000 sözlük namizəd indeksindən kənardadır.
Bu nümunələrdə əsas məhdudiyyət top-20 həddi deyil. Eyni indeks saxlanarsa əlavə
epoxa həmin olmayan namizədi seçim siyahısına gətirməyəcək. CharSpell-in hərf
kodlayıcısı ilə namizəd generatorunun lüğət əhatəsi ayrı məsələlərdir.

Bu çətin nümunələrdə 96/235 nəticə ümumi model dəqiqliyi və ya tətbiqin gələcək
qazancı deyil. Təlim davam edir; sonrakı checkpoint-in sıralaması dəyişə bilər.
Düzgün mətnlərin qorunması bu CharSpell yoxlamasında ölçülməyib.

PunctCase bu nümunələrdə sözlərin leksik variantını əvəz etmir. Onun tətbiq yolu
söz ardıcıllığını qoruyaraq durğu və qəbul edilən registr düzəlişləri edir; bu
240 nümunədə əlavə qəbul edilmiş PunctCase düzəlişi yoxdur.

## Necə təsdiqləndi

- Dəqiq mənbə commit-indən ayrıca surət hazırlandı. Yalnız WordLM seçim
  funksiyasındakı erkən çıxışlar və namizəd qərarları üçün müşahidə qeydləri əlavə edildi.
- Mətn və mail strategiyaları ilə 240 nümunə təkrar işləndi. **Bütün çıxışlar əvvəl
  saxlanmış tətbiq çıxışları ilə simvol-simvol eynidir.**
- Hər problemli token birbaşa mərhələ mətnindəki yerinə uyğunlaşdırıldı; 247 uyğunluq
  birmənalıdır. Hər mərhələ mətni yekun çıxışda dəyişmədən mövcuddur.
- İstinadlar və girişlər ilkin korpusun hash-i və əvvəldən təsdiqlənmiş errata ilə
  yoxlandı. İstinad cavabları dəyişdirilmədi.
- 103 istehsal runtime faylı və 17 JSON model artefaktının hash-i əvvəlki versiya
  ilə eynidir. Git iş qovluğu təmizdir; tətbiq və aktiv təlim dəyişdirilməyib.

Diaqnostika açıq olanda kod düzgün sayılan girişlər üçün də əlavə namizəd qeydi
hesablayır. Normal tətbiq həmin 42 sözü daha əvvəl saxlayır; hesabat onları real
sıralama kimi saymır. İki variantlı əlavə WordLM müqayisələri `wordlm-probes.jsonl.gz`
faylında açıq şəkildə əks-faktual qeyd olunub: verilmiş istinadı müqayisəyə daxil
etmək onun real generator tərəfindən tapıldığını göstərmir.

## Düzəliş üçün prioritetlər

1. Modelin artıq bildiyi söz və şəkilçili formaları məhdud namizəd generatoruna
   ötürmək. Hər səhv cümlə üçün ayrıca əvəzləmə qaydası əlavə etməyə ehtiyac yoxdur.
2. Qarışıq Azərbaycan/ASCII, cümlə əvvəlində böyük hərf və ikihərfli sözlər üçün
   konteksti nəzərə alan seçim yolu hazırlamaq; ad və texniki termin qorumasını yoxlamaq.
3. Etibarlı sözün kontekstdə yanlış məna verməsini, modelin kontekst sübutunu və
   bal fərqi tələblərini ayrıca qiymətləndirmək. Yeni qərarları yalnız bu 240 nümunəyə
   uyğunlaşdırmadan müstəqil düzgün mətn və real səhv materialında sınamaq.
4. 12 söz sərhədi problemi üçün ayrılma namizədi yaratmaq. Tək sözlü CharSpell-dən
   bu əməliyyatı gözləməmək.
5. CharSpell təlimi bitəndə tamamlanmış checkpoint-i eyni sabit nümunələrdə və
   ayrıca düzgün mətn dəstində yoxlamaq; sonra tətbiqə qoşulma qərarı vermək.

`SUMMARY.json` yekun sayları, `per-site.csv` oxunaqlı siyahını,
`per-site.jsonl.gz` isə hər yerin namizədlərini, ballarını, keçid səbəbini və
CharSpell nəticəsini saxlayır. `observations.jsonl.gz` tam müşahidə qeydləridir.
