# Continue the candidate investigation in another chat

Read REPORT.md and SUMMARY.json first. This is a diagnosis of 240 selected development
failures, not a model update. There are247 mismatch sites; do not confuse that with
240 independent single-word errors. The references remain frozen.

1. Download the four pinned files in the Release. Verify the OUTER SHA256SUMS,
   extract candidate-audit-recovery.tar.gz, enter its directory, and run
   `sha256sum -c SHA256SUMS` to verify all inner files.
2. per-site.csv is the readable index. per-site.jsonl.gz contains every observed
   gate, real candidate rank and both model probes. observations.jsonl.gz contains
   full tracing. No original training corpus or checkpoint is inside this archive.
3. Exact public application source:
   https://github.com/Sanan2030/SlothAI/commit/d8a10ec79a498835f1a72655877be47d8e011096
   Clone/checkout that commit and use npm ci and the dictionary import command.
   Source is kept in that repository; this focused archive does not duplicate it.
4. To recalculate the summary from saved observations, decompress the three
   cases.json.gz, mismatch-sites.json.gz and annotated-sites.json.gz files to copies.
   Set SLOTHAI_AUDIT_REPO to the clean pinned source checkout, then run
   `python3 analyze.py`. PROVENANCE.json binds103 runtime files and17 JSON artifacts.
5. A fresh WordLM replay needs an ISOLATED source copy, the same generated
   dictionary, node_modules and the supplied selection-observability.patch.
   Apply the patch only to that isolated copy. Copy replay.ts.txt into that copy's
   root as audit.ts and run `node --import tsx audit.ts --out=/absolute/new/audit`.
   Prepare cases.json there from the saved copy. Output parity is mandatory.
   The patch adds observation of early gates and decisions; it does not change
   the selection conditions. Do not apply it to production or an active training tree.
6. CHARCHECKPOINT_RECOVERY.json pins the remotely checksum-verified archive,
   member and SHA256 of the epoch2 checkpoint used here. Retrieve that checkpoint,
   then run with the existing Torch2.8 CPU environment:
   `python rescore-charspell.py --repo=/pinned/source --checkpoint=/restored/best.pt`.
   This rescores the saved candidates without the large source database. The
   expected235 top choices and relative logits were verified in this investigation.
7. To regenerate CharSpell CANDIDATE RETRIEVAL, the exact full-data/lexicon.sqlite
   is also required. It is retained in the current cloud workspace and excluded
   from this diagnostic archive. Checkpoints alone do not recreate its train-only
   frequencies/index. probe-charspell.py documents the lookup and scoring procedure;
   adjust its workspace paths and use a fresh output directory for any new probe.

The actual model checkpoint used is epoch2, SHA256
7d4338fc926023491d2d2f2c46196f7eb39af8bfad9134793e7ce596ba7e8ae3.
The full CharSpell job may have progressed since this snapshot. Do not restart it
or overwrite its source/config/prepared data. This task performed no training,
model promotion, production patch or reference revision.

Separate model backups:
https://github.com/Sanan2030/SlothAI/releases/tag/charspell-backup-2026-11-04
https://github.com/Sanan2030/SlothAI/releases/tag/punctcase-backup-2026-11-04

Previous full application recovery:
https://github.com/Sanan2030/SlothAI/releases/tag/automatic-models-2026-11-05
