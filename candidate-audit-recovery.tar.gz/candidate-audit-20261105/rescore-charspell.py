"""Verify saved scores from frozen candidate lists; the large SQLite index is unnecessary."""
import argparse,gzip,hashlib,json,sys
from pathlib import Path
import torch
parser=argparse.ArgumentParser();parser.add_argument('--repo',type=Path,required=True);parser.add_argument('--checkpoint',type=Path,required=True);args=parser.parse_args()
out=Path(__file__).resolve().parent;summary=json.loads((out/'charspell-summary.json').read_text())
assert hashlib.sha256(args.checkpoint.read_bytes()).hexdigest()==summary['checkpointSHA256']
sys.path.insert(0,str(args.repo.resolve()))
from training.charspell.model import CharSpell,collate
torch.set_num_threads(1);checkpoint=torch.load(args.checkpoint,map_location='cpu',weights_only=True);config=checkpoint['config'];model=CharSpell(config);model.load_state_dict(checkpoint['state_dict']);model.eval()
records=[json.loads(x) for x in gzip.decompress((out/'charspell-probes.jsonl.gz').read_bytes()).splitlines()];records=[x for x in records if x['supported']];maximum=0;matches=0
with torch.inference_mode():
 for start in range(0,len(records),16):
  batch=records[start:start+16];rows=[{k:r[k] for k in ['input','left','right','candidates']}|{'label':0} for r in batch];logits=model(collate(rows,config,'cpu')).tolist()
  for r,values in zip(batch,logits):
   saved={x['word']:x['logit'] for x in r['ranking']};values=values[:len(r['candidates'])];maximum=max(maximum,max(abs(v-saved[w]) for w,v in zip(r['candidates'],values)));predicted=r['candidates'][max(range(len(values)),key=values.__getitem__)];matches+=predicted==r['predicted']
assert maximum<=1e-5 and matches==len(records)
print(json.dumps({'examples':len(records),'matchingTop1':matches,'maximumLogitDifference':maximum,'tolerance':1e-5,'checkpointSHA256':summary['checkpointSHA256'],'sqliteRequired':False},indent=2))
