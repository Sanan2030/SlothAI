"""Summarize observed gates and read-only model probes; never modify app or gold."""
from pathlib import Path
import collections,csv,gzip,hashlib,io,json,subprocess,os

out=Path(__file__).resolve().parent
repo=Path(os.environ.get('SLOTHAI_AUDIT_REPO','/workspace/SlothAI'))
def read(name):return json.loads((out/name).read_text())
def lines(name):return [json.loads(x) for x in gzip.decompress((out/name).read_bytes()).splitlines()]
def lower(s):return s.translate(str.maketrans({'I':'ı','İ':'i'})).lower()
def sha(b):return hashlib.sha256(b).hexdigest()
sites=read('annotated-sites.json');cases=read('cases.json')
word={x['key']:x for x in lines('wordlm-probes.jsonl.gz')}
char={x['key']:x for x in lines('charspell-probes.jsonl.gz')}
observations=lines('observations.jsonl.gz')
assert len(cases)==len(observations)==240 and len(sites)==247
assert all(x['outputParity'] for x in observations)

# Bind every input/reference to the original public corpus plus approved errata.
corpus=repo/'data/qa/novel-10000-2026-11-04'
manifest=json.loads((corpus/'MANIFEST.json').read_text())
raw=(corpus/'cases.jsonl.gz').read_bytes()
assert sha(raw)==manifest['gzipSHA256']
assert sha(gzip.decompress(raw))==manifest['corpusSHA256']
refs={x['id']:x for x in [json.loads(s) for s in gzip.decompress(raw).splitlines()]}
review=json.loads((corpus/'GOLD_REVIEW.json').read_text())
for change in review['changes']:
 assert refs[change['id']]['expected']==change['before']
 refs[change['id']]['expected']=change['after']
for case in cases:
 assert case['input']==refs[case['id']]['input'] and case['expected']==refs[case['id']]['expected']

# Check that instrumentation and offline probing touched no production runtime/model.
provenance=read('PROVENANCE.json')
for group in ['runtimeSHA256','runtimeJSONSHA256']:
 for name,expected in provenance[group].items():assert sha((repo/name).read_bytes())==expected,name
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)==''

counts=collections.Counter(x['primaryCause'] for x in sites)
actual_ranked=[x for x in sites if x['type']=='one-to-one' and x['observedSelection']['kind']=='selection' and not x['observedSelection']['validRaw']]
present=[x for x in actual_ranked if x['primaryCause']=='insufficient observed lexical evidence']
missing=[x for x in actual_ranked if x['primaryCause']=='gold-missing-from-actual-candidate-list']
first=[x for x in present if x['observedSelection']['candidates'][0]['word']==lower(x['expectedWords'][0])]
margin=[x for x in first if x['observedSelection']['candidates'][0]['score']-x['observedSelection']['candidates'][1]['score']>=4.605170185988092]
assert len(actual_ranked)==78 and len(present)==45 and len(missing)==33 and len(first)==31 and len(margin)==15
for x in present:
 assert not next(c for c in x['observedSelection']['candidates'] if c['word']==lower(x['expectedWords'][0]))['evidence']
no_generator_hit=[]
for x in missing:
 a=word[x['key']]['availability']
 no_generator_hit.append(not any(a[k] for k in ['goldInDictionary','goldInEdits24','goldIsMorphology','goldIsRuleProposal']))
assert all(no_generator_hit)
wrong_char=[x for x in char.values() if x.get('supported') and x['goldRetrieved'] and not x['top1Correct']]
summary={'scope':'240 selected failures from frozen assistant-authored development data; observational diagnosis, not blind acceptance or general accuracy.',
 'sourceCommit':read('PROVENANCE.json')['sourceCommit'],'corpusSHA256':manifest['corpusSHA256'],
 'goldReviewSHA256':sha((corpus/'GOLD_REVIEW.json').read_bytes()),'cases':240,'mismatchSites':247,'oneToOneSites':235,'wordBoundarySites':12,
 'primaryCauseCountsBySite':dict(counts),'casesWithCause':{c:len({x['id'] for x in sites if x['primaryCause']==c}) for c in counts},
 'wordlm':{'eligibleAndActuallyRankedSites':78,'goldPresentInActualCandidates':45,'goldMissingFromActualCandidates':33,
 'goldJointRank1Of45':31,'goldJointRankBelow1Of45':14,'goldHasRequiredRetainedNgramEvidenceOf45':0,
 'goldRank1AlsoMeetsScoreMargin':15,'goldRank1ButBelowScoreMargin':16,
 'missing33GoldInLMVocabulary':sum(word[x['key']]['goldRecognition']['inLMVocabulary'] for x in missing),
 'missing33GoldKnownToExistingLexicalServices':sum(word[x['key']]['goldRecognition']['known'] for x in missing),
 'missing33FoundByExistingSourcesEvenAt24Edits':0,
 'all235GoldInLMVocabulary':sum(x['goldRecognition']['inLMVocabulary'] for x in word.values()),
 'validInputGateSites':42,'validInputGateDictionaryExact':sum(word[x['key']]['rawRecognition']['dictionaryExact'] for x in sites if x['primaryCause']=='valid-input-preservation-gate'),
 'diagnosticCaveat':'The diagnostic sink computes candidate lists for valid inputs. Normal production returns earlier for those42; they are not counted as actual ranking. Two-candidate reference-supplied probes are explicitly counterfactual, not retrieval success.'},
 'charspell':read('charspell-summary.json')|{'retrievedButRankedWrong':len(wrong_char),'retrievedButWrongRetainedInput':sum(x['predicted']==x['input'] for x in wrong_char),'retrievedButWrongOtherCandidate':sum(x['predicted']!=x['input'] for x in wrong_char)},
 'checks':{'shadowReplayOutputsEqualProduction':240,'postWordLMErrorTokenOverrides':0,'unambiguousFragmentAndTokenMapping':247,'corpusAndApprovedReferencesVerified':240,
 'productionRuntimeHashesUnchanged':len(provenance['runtimeSHA256']),'runtimeJSONHashesUnchanged':len(provenance['runtimeJSONSHA256']),'gitWorkingTreeClean':True},
 'policyChanged':False,'trainingPerformed':False,'modelsPromoted':False,'referencesChanged':False}
(out/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
why={
 'non-ascii-input-gate':'Girişdə ASCII-dən kənar hərf var; WordLM seçim funksiyası bu sözü sıralamaya buraxmır.',
 'uppercase-input-gate':'Girişdə böyük hərf var; WordLM-in kiçik ASCII söz şərti ödənmir.',
 'word-length-input-gate':'İkihərfli de sözü minimum üç hərf şərtinə görə sıralanmır.',
 'valid-input-preservation-gate':'Mövcud lüğət/morfologiya girişi düzgün forma sayır; normal tətbiq WordLM seçimindən əvvəl bu sözü saxlayır.',
 'gold-missing-from-actual-candidate-list':'Düzgün forma real namizəd siyahısına daxil olmur; mövcud mənbələr və 24-lük redaktə siyahısı da onu təklif etmir.',
 'insufficient observed lexical evidence':'Düzgün namizəd var, lakin saxlanmış konkret biqram/triqram kontekst sübutu yoxdur; qəbul şərti ödənmir.',
 'word-boundary-not-representable-by-word-ranker':'Bir söz iki sözə ayrılmalıdır; bir söz əvəz edən WordLM/CharSpell namizədi bunu ifadə etmir.'}
records=[]
for s in sites:
 e=s['observedSelection'];w=word.get(s['key']);c=char[s['key']]
 actually=e['kind']=='selection' and not e.get('validRaw',False) and s['type']=='one-to-one'
 target=lower(s['expectedWords'][0]) if s['type']=='one-to-one' else None
 rank=next((i+1 for i,r in enumerate(e.get('candidates',[])) if r['word']==target),None) if actually else None
 records.append({**s,'whyAZ':why[s['primaryCause']],'productionRanked':actually,'productionGoldRank':rank,
  'diagnosticOnlyCandidates':e['kind']=='selection' and e.get('validRaw',False),'wordlmProbe':w,'charspellProbe':c})
(out/'per-site.jsonl.gz').write_bytes(gzip.compress(('\n'.join(json.dumps(x,ensure_ascii=False) for x in records)+'\n').encode()))
fields=['key','id','raw','actual','expected','cause','productionRanked','productionGoldRank','goldInLM','charspellRetrieved','charspellGoldRank','why']
with (out/'per-site.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
 for x in records:
  w=x['wordlmProbe'];c=x['charspellProbe'];writer.writerow({'key':x['key'],'id':x['id'],'raw':' '.join(x['rawWords']),'actual':' '.join(x['actualWords']),'expected':' '.join(x['expectedWords']),'cause':x['primaryCause'],'productionRanked':x['productionRanked'],'productionGoldRank':x['productionGoldRank'],'goldInLM':w['goldRecognition']['inLMVocabulary'] if w else None,'charspellRetrieved':c.get('goldRetrieved'),'charspellGoldRank':c.get('goldRank'),'why':x['whyAZ']})
print(json.dumps(summary,ensure_ascii=False,indent=2))
