import sys,json,hashlib,gzip,sqlite3
from pathlib import Path
import torch
sys.path.insert(0,'/workspace/SlothAI')
from training.candidates import CandidateIndex,deletions,distance
from training.charspell.model import CharSpell,collate
from training.text import lower,fold
root=Path('/workspace/SlothAI');out=root/'artifacts/qa/candidate-audit-20261105';session=root/'artifacts/training/sessions/20261104-charspell'
torch.set_num_threads(1)
source=session/'charspell-full/best.pt';raw=source.read_bytes();digest=hashlib.sha256(raw).hexdigest();pinned=out/'pinned-charspell-best.pt';pinned.write_bytes(raw)
checkpoint=torch.load(pinned,map_location='cpu',weights_only=True);config=checkpoint['config']
model=CharSpell(config);model.load_state_dict(checkpoint['state_dict']);model.eval()
index=CandidateIndex(session/'full-data/lexicon.sqlite',config['prefixLength'])
sites=json.loads((out/'mismatch-sites.json').read_text());prepared=[];records=[]
for site in sites:
 if site['type']!='one-to-one':
  records.append({'key':site['key'],'id':site['id'],'supported':False,'reason':'one-to-many word boundary; CharSpell is a one-to-one word scorer'});continue
 target=lower(site['expectedWords'][0]);results=[]
 for mode,word,left,right in [('original-input',lower(site['rawWords'][0]),' '.join(site['leftRawContext']),' '.join(site['rightRawContext']))]:
  alternatives=[word,*index.lookup(word,config['maxCandidates']-1)]
  entry={'key':site['key'],'id':site['id'],'supported':True,'mode':mode,'input':word,'expected':target,'left':left,'right':right,'candidates':alternatives,'goldRetrieved':target in alternatives,'sourceVocabularyHasGold':index.db.execute('SELECT 1 FROM words WHERE word=?',(target,)).fetchone() is not None}
  if target not in alternatives:
   if not entry['sourceVocabularyHasGold']:reason='gold-absent-from-150k-vocabulary'
   elif distance(fold(word),fold(target))>2:reason='folded-edit-distance-over-two'
   elif not deletions(fold(word)[:config['prefixLength']]).intersection(deletions(fold(target)[:config['prefixLength']])):reason='prefix-deletion-index-miss'
   else:
    expanded=[word,*index.lookup(word,4096)]
    if target in expanded:reason='top-20-candidate-cap';entry['expandedGoldPosition']=expanded.index(target)+1
    else:reason='prefix-query-top-4096-pool-cap'
   entry['retrievalMissReason']=reason
  records.append(entry);prepared.append((entry,{'input':word,'left':left,'right':right,'candidates':alternatives,'label':0}))
with torch.inference_mode():
 for start in range(0,len(prepared),16):
  batch=prepared[start:start+16];scores=model(collate([x[1] for x in batch],config,'cpu')).tolist()
  for (entry,row),values in zip(batch,scores):
   ranked=sorted(zip(entry['candidates'],values[:len(entry['candidates'])]),key=lambda x:-x[1]);entry['ranking']=[{'word':w,'logit':v} for w,v in ranked];entry['predicted']=ranked[0][0];entry['goldRank']=next((i+1 for i,(w,v) in enumerate(ranked) if w==entry['expected']),None);entry['top1Correct']=entry['predicted']==entry['expected'];entry['top3Correct']=entry['goldRank'] is not None and entry['goldRank']<=3
index.close()
(out/'charspell-probes.jsonl.gz').write_bytes(gzip.compress(('\n'.join(json.dumps(x,ensure_ascii=False) for x in records)+'\n').encode()))
from collections import Counter
supported=[x for x in records if x['supported']];hits=[x for x in supported if x['goldRetrieved']]
summary={'scope':'Read-only offline best-checkpoint probe on the already-selected development failures. No training, no promotion, no reference injection. Top1 is conditional on this generated candidate list and not safe app correction quality.','checkpointSHA256':digest,'checkpointEpoch':checkpoint['epoch'],'trainingReportStatus':json.loads((session/'charspell-full/report.json').read_text())['status'],'cases':len(set(x['id'] for x in records)),'mismatchSites':len(sites),'oneToOneSites':len(supported),'unsupportedBoundarySites':len(records)-len(supported),'goldRetrieved':len(hits),'goldMissing':len(supported)-len(hits),'top1CorrectOverAllOneToOne':sum(x['top1Correct'] for x in supported),'top3CorrectOverAllOneToOne':sum(x['top3Correct'] for x in supported),'top1CorrectWhenRetrieved':sum(x['top1Correct'] for x in hits),'missReasons':dict(Counter(x['retrievalMissReason'] for x in supported if not x['goldRetrieved'])),'newModelUsedInApp':False}
(out/'charspell-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
