# Continue this QA work in a new chat

1. Verify the OUTER `SHA256SUMS`, extract the archive, enter this directory,
   then run `sha256sum -c SHA256SUMS` to verify every inner file.
2. Clone https://github.com/Sanan2030/SlothAI and check out `8a7dd0874deb74b2f11e89035f777d32309eb1c2`.
   `application-source.tar.gz` is a separate exact source fallback. It contains
   no Git history; novelty rechecking needs the pinned legacy commit in Git.
3. Read `docs/qa/novel-10000-2026-11-04.md`, the corpus README, MANIFEST,
   GOLD_REVIEW and `comparison/summary.json`. Inputs and original references
   are frozen. Apply only the explicit gold errata; never fit references to outputs.
4. All before/after outputs are in `baseline/results.jsonl.gz` and
   `final/results.jsonl.gz`. Decompress copies with `gzip -dk` before running
   compare/trace commands. `comparison/remaining-errors.jsonl.gz` is the next
   work queue. `final/error-traces.jsonl.gz` records observed stage decisions.
5. Run `npm ci`, then the commands in the corpus README. Use fresh output
   directories. Browser QA requires a running production build and Chromium;
   set PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH only for an existing binary.
6. `RUN_PROVENANCE.json` proves all evaluated TypeScript runtime files match
   the source commit. The archived reports originally record the pre-commit
   base plus working-tree hashes, not a falsely claimed committed run.

The dataset is assistant-authored compositional development material, not a
blind or independently human-labelled benchmark. Open disagreements remain.
PunctCase's opt-in path was tested; zero accepted edits in this corpus is not
evidence that its training adds this measured improvement. No model retraining
used these QA cases. Do not restart or overwrite unrelated training jobs.

Original six training gzip files and bulk prepared training data are excluded.
Separate training recovery Releases:
- https://github.com/Sanan2030/SlothAI/releases/tag/punctcase-backup-2026-11-04
- https://github.com/Sanan2030/SlothAI/releases/tag/charspell-backup-2026-11-04
