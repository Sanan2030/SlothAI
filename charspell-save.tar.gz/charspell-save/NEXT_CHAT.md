# CharSpell cloud job — 4 November 2026

Read charspell-job.json AND live process identities before claiming this job is running. Read github-backup.json for the last remotely verified backup. WordLM and PunctCase are already fitted/integrated; this job runs only CharSpell.

The pipeline prepares the unchanged accepted corpus for CharSpell, runs a fresh 100k/10k smoke, then prepares and trains the complete original train/validation splits. No test fitting, no threshold calibration, no automatic app promotion. Original archives/corpus and bulk task files are not uploaded.

CPU: four threads, no GPU. Processes require this cloud instance to remain running. Resume neural fitting only with matching completed-epoch checkpoint and --resume; partial epochs repeat. Preserve all partial outputs.

GitHub Release: https://github.com/Sanan2030/SlothAI/releases/tag/charspell-backup-2026-11-04 . Use its latest pinned downloads and RESTORE.md; do not assume the initial Source code ZIP contains later checkpoints.
