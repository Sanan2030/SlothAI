"""Publish corpus-free, checksum-verified CharSpell snapshots through Git transport."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import urllib.request

BASE_TAG = 'charspell-backup-2026-11-04'
REPO = 'Sanan2030/SlothAI'


class GitHubBackup:
    def __init__(self, root, session):
        self.root, self.session = root, session
        self.tree = session / '.backup-tree'
        self.initial_pushed = False
        self.release_exists = False
        self.checkpoints = []

    def run(self, *args, cwd=None):
        result = subprocess.run(args, cwd=cwd or self.tree, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                timeout=90)
        if result.returncode:
            raise RuntimeError(f'{args[0]} failed ({result.returncode}): {result.stderr[-1500:]}')
        return result.stdout.strip()

    def setup(self):
        if (self.tree / '.git').exists():
            return
        self.tree.mkdir(exist_ok=False)
        self.run('git', 'init', '--quiet')
        for key in ('user.name', 'user.email'):
            value = self.run('git', 'config', '--get', key, cwd=self.root)
            self.run('git', 'config', key, value)
        self.run('git', 'remote', 'add', 'origin', f'https://github.com/{REPO}.git')

    def publish(self, state, latest_path, update_archive):
        from training.common import read_json, sha256, write_json
        self.setup()
        latest = read_json(latest_path)
        archive = self.tree / 'charspell-save.tar.gz'
        if update_archive or not archive.exists():
            shutil.copyfile(latest['archive'], archive)
        reports = {}
        for name in ('charspell-smoke', 'charspell-full'):
            path = self.session / name / 'report.json'
            if path.exists():
                report = read_json(path)
                reports[name] = {key: report.get(key) for key in
                                ('status', 'selectedEpoch', 'validation', 'bestCheckpointSHA256',
                                 'lastCheckpointSHA256', 'artifactSHA256', 'elapsedSeconds')}
                reports[name]['completedEpochs'] = len(report.get('epochs', []))
        recovery = {'schemaVersion': 1, 'savedAtUTC': datetime.now(timezone.utc).isoformat(),
                    'job': state, 'reports': reports, 'previousCheckpointSaves': self.checkpoints,
                    'archiveSHA256': sha256(archive), 'originalCorpusUploaded': False,
                    'bulkPreparedDataUploaded': False, 'sourceCommit': state['repositoryHEAD']}
        write_json(self.tree / 'RECOVERY.json', recovery)
        restore = f'''# CharSpell recovery

Check out application/training source commit `{state['repositoryHEAD']}`.
Latest checkpoint archive: `charspell-save.tar.gz`; state: `RECOVERY.json`.
Verify the four recovery files with `sha256sum -c SHA256SUMS`, extract the
archive and verify its inner `charspell-save/SHA256SUMS`. It contains code,
configuration, reports, log tails and the latest available best/last checkpoints.
Earlier completed-epoch saves remain reachable through the immutable Git tags
and pinned commit links in RECOVERY.json / this release's checkpoint history.

The accepted original corpus and bulk prepared task data are EXCLUDED.
For continuation they must be available separately at their original paths
under `/workspace/SlothAI`. Never substitute data or regenerate synthetic pairs.
The exact corpus manifest and prepared/configuration/gate receipts are in the
archive. Reconstructed task files must match every saved hash before use;
restore the original preparation metadata when restoring that exact dataset.
Run `training.common.verify_prepared` before invoking any resume command.

Inspect report/progress files and verify Linux PID start identities before
claiming a process is alive. The stored running flag is historical after a
machine stops. Original supervisor: `{self.session}/supervise-charspell.py`.
Preserve partial outputs; existing output directories are never overwritten.
Interrupted preparation needs a NEW output directory. A partial first epoch
has no resumable optimizer checkpoint yet; restart fitting in a new run directory.
After a completed epoch, use the existing trainer's guarded `--resume` with the
SAME prepared dataset, configuration, runtime and best/last checkpoints:

```
.venv-training/bin/python -m training.cli train charspell \\
  --data=/path/to/original-data --out=/path/to/restored-run --device=cpu \\
  --resume --smoke-receipt=/path/to/charspell-smoke/report.json
```

The smoke receipt is required for full training. Partially executed epochs
repeat from the last completed-epoch optimizer/RNG state. If no checkpoints
exist, this is a launch/preparation save, not evidence of learned weights.
Successful smoke permits the supervised full prepare/train sequence. Inspect
and deliberately continue remaining phases after interruption; do not start
another supervisor over an existing job. CPU processes require a running instance.
WordLM and PunctCase are already complete; this job never retrains them.
Validation is synthetic/source-derived; no real-user acceptance or automatic
app promotion is claimed.
'''
        (self.tree / 'RESTORE.md').write_text(restore)
        names = ('charspell-save.tar.gz', 'RECOVERY.json', 'RESTORE.md')
        (self.tree / 'SHA256SUMS').write_text(''.join(sha256(self.tree / n)+'  '+n+'\n' for n in names))
        self.run('git', 'add', '--all')
        self.run('git', 'commit', '--quiet', '-m', f'[skip ci] CharSpell recovery: {state["phase"]} {state["status"]}')
        commit = self.run('git', 'rev-parse', 'HEAD')
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        tag = f'charspell-save-20261104-{stamp}' if self.initial_pushed else BASE_TAG
        self.run('git', 'push', 'origin', f'HEAD:refs/tags/{tag}')
        self.initial_pushed = True
        base_url = f'https://raw.githubusercontent.com/{REPO}/{commit}'
        for name in (*names, 'SHA256SUMS'):
            with urllib.request.urlopen(base_url+'/'+name, timeout=60) as response:
                actual = hashlib.sha256(response.read()).hexdigest()
            if actual != sha256(self.tree / name):
                raise ValueError('Remote read-back checksum mismatch: '+name)
        current = {'status': 'published-and-download-verified', 'atUTC': datetime.now(timezone.utc).isoformat(),
                   'tag': tag, 'commit': commit, 'phase': state['phase'], 'reports': reports,
                   'archiveSHA256': sha256(archive), 'archiveURL': base_url+'/charspell-save.tar.gz',
                   'recoveryURL': base_url+'/RECOVERY.json',
                   'releaseURL': f'https://github.com/{REPO}/releases/tag/{BASE_TAG}',
                   'originalCorpusUploaded': False, 'bulkPreparedDataUploaded': False}
        if update_archive:
            self.checkpoints.append({k: current[k] for k in ('atUTC', 'tag', 'commit', 'phase', 'reports', 'archiveURL')})
        notes = f'''CharSpell supervised CPU experiment; latest remotely verified save below.

Pipeline: CharSpell-only prepare (100k/10k), smoke, full prepare, full fitting.
Four CPU threads, unchanged accepted train/validation splits, maximum 6 full
epochs with patience 2. WordLM/PunctCase are already complete and are not retrained.

Current phase: **{state['phase']}**. Job status: **{state['status']}**.
Optimizer steps observed: **{state.get('progress', {}).get('optimizerStepsOverall', 0)}**.
Training started (observed optimizer steps or completed run): **{state['trainingStarted']}**.
Saved at {current['atUTC']}.

Use these latest pinned downloads (the automatic Source code ZIP/TAR below
corresponds to the INITIAL launch tag, not subsequent checkpoint updates):

- [charspell-save.tar.gz]({base_url}/charspell-save.tar.gz)
- [RECOVERY.json]({base_url}/RECOVERY.json)
- [RESTORE.md]({base_url}/RESTORE.md)
- [SHA256SUMS]({base_url}/SHA256SUMS)

All four files were independently downloaded and hash-verified. The archive
has an inner SHA256SUMS. Original corpus / original gzip archives / bulk task
files are excluded. Resuming fitting requires separately available matching
corpus and prepared data. Processes require this cloud instance to remain running.
Weights are saved after completed epochs; a partial first epoch cannot yet resume.
No full completion, natural-text quality acceptance or app promotion is claimed
unless the corresponding completed report is present.

Application/training source: [{state['repositoryHEAD'][:7]}](https://github.com/{REPO}/commit/{state['repositoryHEAD']}).

## Snapshot history

'''
        for item in self.checkpoints:
            epochs = ', '.join(f'{name}: {value["completedEpochs"]} epochs' for name, value in item['reports'].items()) or 'no model checkpoint yet'
            notes += f'- {item["atUTC"]} — {item["phase"]}, {epochs}: [immutable save]({item["archiveURL"]})\n'
        note_path = self.session / 'release-notes.md'
        note_path.write_text(notes)
        if not self.release_exists:
            exists = subprocess.run(['gh', 'release', 'view', BASE_TAG, '--repo', REPO],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60).returncode == 0
            if not exists:
                self.run('gh', 'release', 'create', BASE_TAG, '--repo', REPO, '--verify-tag', '--prerelease',
                         '--title', 'CharSpell training backups — 4 November 2026', '--notes-file', str(note_path))
            self.release_exists = True
        self.run('gh', 'release', 'edit', BASE_TAG, '--repo', REPO, '--notes-file', str(note_path))
        write_json(self.session / 'github-backup.json', current)
        state['lastRemoteSnapshot'] = current
