"""Explicit supervised PunctCase job; local recovery snapshots contain no corpus files."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT = Path('/workspace/SlothAI')
SESSION = Path(__file__).resolve().parent
PYTHON = ROOT / '.venv-training/bin/python'
STATE = SESSION / 'punctcase-job.json'
sys.path.insert(0, str(ROOT))
from training.common import sha256, read_json, write_json


def now():
    return datetime.now(timezone.utc).isoformat()


def backup(state):
    """Atomically publish a verified snapshot of code, run metadata and checkpoints."""
    destination = SESSION / 'backups'
    destination.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.snapshot-', dir=destination) as temporary:
        staging = Path(temporary) / 'punctcase-save'
        staging.mkdir()
        files = [SESSION / name for name in ('punctcase-job.json', 'session.json', 'events.jsonl',
                 'NEXT_CHAT.md', 'PROJECT_FINDINGS.md', 'recovery-report.json',
                 'requirements-resolved.txt', 'working-changes.patch', 'supervise-punctcase.py', 'recover-corpus.py')]
        files.extend((SESSION / 'training-source').rglob('*'))
        for data in ('smoke-data', 'full-data'):
            files.extend(SESSION / data / name for name in ('prepared.json', 'config.json', 'data-gate.json', 'data-gate-receipt.json'))
        for run in ('punctcase-smoke', 'punctcase-full'):
            files.extend(SESSION / run / name for name in ('best.pt', 'last.pt', 'report.json', 'progress.json', 'model-card.json'))
        for source in files:
            if source.is_file():
                target = staging / source.relative_to(SESSION)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
        for log in (SESSION / 'logs').glob('*.log'):
            target = staging / 'logs' / (log.name + '.tail')
            target.parent.mkdir(parents=True, exist_ok=True)
            with log.open('rb') as source:
                source.seek(max(0, log.stat().st_size - 262144))
                target.write_bytes(source.read())
        for run in ('punctcase-smoke', 'punctcase-full'):
            report_path = staging / run / 'report.json'
            if report_path.exists():
                report = read_json(report_path)
                for name, key in (('best.pt', 'bestCheckpointSHA256'), ('last.pt', 'lastCheckpointSHA256')):
                    if key in report and sha256(staging / run / name) != report[key]:
                        return  # Epoch publication raced this snapshot; retry on the next poll.
        sums = ''.join(sha256(path) + '  ' + str(path.relative_to(staging)) + '\n'
                       for path in sorted(staging.rglob('*')) if path.is_file())
        (staging / 'SHA256SUMS').write_text(sums)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        archive = destination / ('punctcase-save-' + stamp + '.tar.gz')
        with tarfile.open(archive.with_suffix('.partial'), 'w:gz') as handle:
            handle.add(staging, arcname='punctcase-save')
        archive.with_suffix('.partial').replace(archive)
        with tarfile.open(archive, 'r:gz') as handle:
            for line in sums.splitlines():
                digest, name = line.split('  ', 1)
                if hashlib.sha256(handle.extractfile('punctcase-save/' + name).read()).hexdigest() != digest:
                    raise ValueError('Snapshot checksum mismatch: ' + name)
        latest = SESSION / 'punctcase-save-latest.tar.gz'
        link = latest.with_suffix('.partial')
        if link.exists():
            link.unlink()
        os.link(archive, link)
        link.replace(latest)
        write_json(destination / 'latest.json', {'createdAtUTC': now(), 'archive': str(archive),
                   'sha256': sha256(archive), 'bytes': archive.stat().st_size,
                   'containsOriginalCorpus': False, 'driveUploaded': False,
                   'phase': state['phase'], 'progress': state.get('progress'),
                   'resumeRequiresOriginalAcceptedCorpusAndPreparedData': True})


def bundle_prepared(path, state):
    archive = SESSION / 'backups' / (path.name + '-task-data.tar.gz')
    if archive.exists():
        raise ValueError('Prepared data backup already exists; refusing overwrite')
    with tarfile.open(archive.with_suffix('.partial'), 'w:gz') as handle:
        handle.add(path, arcname=path.name)
    archive.with_suffix('.partial').replace(archive)
    state.setdefault('preparedBackups', []).append({'path': str(archive), 'sha256': sha256(archive),
                                                   'bytes': archive.stat().st_size, 'driveUploaded': False})


def main():
    if '--status' in sys.argv:
        print(STATE.read_text() if STATE.exists() else json.dumps({'status': 'not-started'}))
        return
    if STATE.exists():
        raise ValueError('Job already exists. Inspect its status; do not duplicate or implicitly resume it.')
    state = {'status': 'running', 'phase': 'starting', 'startedAtUTC': now(), 'supervisorPID': os.getpid(),
             'repositoryHEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
             'trainingStarted': False, 'stages': [], 'device': 'cpu', 'cpuThreads': 4,
             'driveBackup': 'blocked-no-connected-writer', 'originalCorpusUploaded': False,
             'appIntegration': 'pending-full-training-and-validation',
             'limitations': ['Processes require this cloud instance to remain running.',
                             'Local snapshots have not been uploaded to Drive.',
                             'Source-split label validation is not independent human-reviewed quality.']}
    semantic = {str(p.relative_to(ROOT)): sha256(p) for p in (ROOT / 'training').rglob('*.py')}
    state['semanticSourceSHA256'] = semantic
    write_json(STATE, state)
    backup(state)
    commands = [
        ('prepare-smoke', [str(PYTHON), '-m', 'training.cli', 'prepare', '--profile=smoke', '--stages', 'punctcase', '--out=' + str(SESSION / 'smoke-data')], 'smoke-data'),
        ('train-smoke', [str(PYTHON), '-m', 'training.cli', 'train', 'punctcase', '--data=' + str(SESSION / 'smoke-data'), '--out=' + str(SESSION / 'punctcase-smoke'), '--device=cpu'], 'punctcase-smoke'),
        ('prepare-full', [str(PYTHON), '-m', 'training.cli', 'prepare', '--profile=full', '--stages', 'punctcase', '--out=' + str(SESSION / 'full-data')], 'full-data'),
        ('train-full', [str(PYTHON), '-m', 'training.cli', 'train', 'punctcase', '--data=' + str(SESSION / 'full-data'), '--out=' + str(SESSION / 'punctcase-full'), '--device=cpu', '--smoke-receipt=' + str(SESSION / 'punctcase-smoke/report.json')], 'punctcase-full'),
    ]
    child = None
    try:
        for phase, command, directory in commands:
            if any(sha256(ROOT / name) != digest for name, digest in semantic.items()):
                raise ValueError('Training source changed after this job was launched')
            if (SESSION / directory).exists():
                raise ValueError('Output exists; refusing overwrite: ' + directory)
            state['phase'] = phase
            state.pop('progress', None)
            entry = {'phase': phase, 'command': command, 'startedAtUTC': now(), 'status': 'running',
                     'log': str(SESSION / 'logs' / (phase + '.log'))}
            state['stages'].append(entry)
            write_json(STATE, state)
            backup(state)
            started = time.monotonic()
            environment = {**os.environ, 'OMP_NUM_THREADS': '4', 'MKL_NUM_THREADS': '4', 'OPENBLAS_NUM_THREADS': '1'}
            with Path(entry['log']).open('xb') as log:
                child = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                         stdin=subprocess.DEVNULL, env=environment, start_new_session=True)
                entry['pid'] = child.pid
                previous_progress = None
                while child.poll() is None:
                    free = shutil.disk_usage(ROOT).free
                    state.update(updatedAtUTC=now(), freeDiskGiB=round(free / 2**30, 2))
                    if free < 4 * 2**30:
                        raise ValueError('Free disk reserve fell below 4 GiB')
                    progress = SESSION / directory / 'progress.json'
                    changed = False
                    if progress.exists():
                        current = read_json(progress)
                        state['progress'] = current
                        state['trainingStarted'] |= current.get('optimizerStepsOverall', 0) > 0
                        changed = current != previous_progress
                        previous_progress = current
                    write_json(STATE, state)
                    if changed:
                        backup(state)
                    time.sleep(10)
                entry.update(exitCode=child.returncode, elapsedSeconds=time.monotonic() - started,
                             finishedAtUTC=now(), status='completed' if child.returncode == 0 else 'failed')
                if child.returncode:
                    raise ValueError(phase + ' failed; see ' + entry['log'])
                child = None
            if phase.startswith('prepare-'):
                prepared = read_json(SESSION / directory / 'prepared.json')
                if prepared.get('status') != 'prepared' or prepared.get('preparedStages') != ['punctcase']:
                    raise ValueError('Unexpected preparation result')
                bundle_prepared(SESSION / directory, state)
            else:
                report = read_json(SESSION / directory / 'report.json')
                if report.get('status') != 'completed' or sha256(SESSION / directory / report['artifact']) != report['artifactSHA256']:
                    raise ValueError('Training exit lacks a matching completed model report')
                entry['validation'] = report['validation']
                state['trainingStarted'] = True
            write_json(STATE, state)
            backup(state)
        state.update(status='training-completed-awaiting-app-integration', phase='completed', finishedAtUTC=now())
    except BaseException as error:
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGINT)
            try:
                child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                child.terminate()
                child.wait(timeout=30)
        state.update(status='failed', error=repr(error), finishedAtUTC=now())
        raise
    finally:
        write_json(STATE, state)
        backup(state)


if __name__ == '__main__':
    main()
