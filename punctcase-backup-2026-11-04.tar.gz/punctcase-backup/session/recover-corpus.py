"""Recover the exact accepted clean rows from their verified redundant pair records."""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import shutil
import sys
import tempfile

ROOT = Path('/workspace/SlothAI')
SESSION = Path(__file__).resolve().parent
ARCHIVES = SESSION / 'received-20261102/archives'
DESTINATION = ROOT / 'data/corpus/az-v1'
FIELDS = ('id', 'documentId', 'sourceId', 'text', 'protectedTerms')
sys.path.insert(0, str(ROOT))
from training.common import receipt, sha256, verify_files, write_json


def main():
    accepted, manifest = receipt()
    compressed = json.loads((ROOT / 'docs/stage1/collection/compressed-parts.json').read_text())['parts']
    report = {'status': 'recovering', 'startedAtUTC': datetime.now(timezone.utc).isoformat(),
              'manifestSHA256': accepted['manifestSHA256'], 'trainingStarted': False,
              'method': 'Project unchanged original clean fields from hash-verified redundant pair rows; require exact accepted raw bytes/hash.',
              'compressedInputs': [], 'rawOutputs': []}
    report_path = SESSION / 'recovery-report.json'
    write_json(report_path, report)
    if DESTINATION.exists():
        raise ValueError('Destination exists; refusing overwrite')
    for part in compressed:
        if part['file'] == 'train.jsonl.gz':
            continue  # Known corrupt input is preserved and never consumed.
        path = ARCHIVES / part['file']
        digest = sha256(path)
        if path.stat().st_size != part['bytes'] or digest != part['sha256']:
            raise ValueError('Compressed input mismatch: ' + part['file'])
        report['compressedInputs'].append({'file': part['file'], 'sha256': digest,
                                            'bytes': path.stat().st_size})
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.exact-recovery-', dir=DESTINATION.parent) as temporary:
        staging = Path(temporary) / 'corpus'
        staging.mkdir()
        for name, expected in manifest['files'].items():
            target = staging / name
            digest, size, lines = hashlib.sha256(), 0, 0
            with target.open('xb') as output:
                if name == 'train.jsonl':
                    with gzip.open(ARCHIVES / 'train-pairs.jsonl.gz', 'rt', encoding='utf-8') as source:
                        for line in source:
                            pair = json.loads(line)
                            if pair['text'] != pair['target'] or pair['errorOrigin'] != 'synthetic':
                                raise ValueError('Redundant clean fields are inconsistent')
                            row = {key: pair[key] for key in FIELDS}
                            if manifest['assignments'].get(row['sourceId']) != 'train':
                                raise ValueError('Source split mismatch')
                            block = (json.dumps(row, ensure_ascii=False) + '\n').encode('utf-8')
                            output.write(block)
                            digest.update(block)
                            size += len(block)
                            lines += 1
                            if lines % 100000 == 0:
                                print(json.dumps({'phase': 'exact-clean-field-recovery', 'rows': lines}), flush=True)
                else:
                    with gzip.open(ARCHIVES / (name + '.gz'), 'rb') as source:
                        for block in iter(lambda: source.read(1024 * 1024), b''):
                            output.write(block)
                            digest.update(block)
                            size += len(block)
                            lines += block.count(b'\n')
            actual = digest.hexdigest()
            if size != expected['bytes'] or actual != expected['sha256']:
                raise ValueError('Recovered/decompressed file does not match accepted bytes: ' + name)
            split = name.split('-')[0].split('.')[0]
            if lines != manifest['splitCounts'][split]:
                raise ValueError('Raw row count mismatch: ' + name)
            report['rawOutputs'].append({'file': name, 'bytes': size, 'sha256': actual, 'rows': lines,
                                         'exactAcceptedMatch': True})
            print(json.dumps(report['rawOutputs'][-1]), flush=True)
            write_json(report_path, report)
        shutil.copyfile(ROOT / 'docs/stage1/collection/MANIFEST.json', staging / 'MANIFEST.json')
        verify_files(staging)
        staging.rename(DESTINATION)
    report.update(status='recovered-and-verified', corpus=str(DESTINATION),
                  finishedAtUTC=datetime.now(timezone.utc).isoformat(),
                  acceptedRawFiles=6, sourceRowsChanged=0)
    write_json(report_path, report)
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
