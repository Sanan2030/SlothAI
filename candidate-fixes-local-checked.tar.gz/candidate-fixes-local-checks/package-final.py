"""Package pinned candidate fixes, before/after evidence and restoration instructions."""
import argparse, hashlib, json, shutil, subprocess, tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path('artifacts/qa/candidate-fixes-20261105');base=Path('artifacts/qa/automatic-models-20261105/final')
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
run=lambda *args:subprocess.check_output(args)
final=read(root/'final-v8/summary.json');browser=read(root/'browser/summary.json');comparison=read(root/'comparison/summary.json')
assert final['totalDistinctInputs']==10000
assert all(r['cases']==10000 and r['errors']==r['unstable']==0 for r in final['summary'].values())
assert all(r['cases']==r['automaticModelRequests']==10000 and r['exceptions']==r['nodeParityDifferences']==0 for r in browser['totals'].values())
assert browser['requireAutomatic'] and browser['legacyFalse'] and browser['transformHTTPRequests']==0
assert comparison['finalResultsSHA256']==sha((root/'final-v8/results.jsonl').read_bytes())
for name,h in final['runtimeSHA256'].items():
 assert sha(run('git','show',a.source+':'+name))==h==sha(Path(name).read_bytes()),name
baseCommit=final['sourceCommit']
paths=lambda commit:[s for s in run('git','ls-tree','-r','--name-only',commit,'lib/editor','lib/strategies').decode().splitlines() if s.endswith('.json')]
old=paths(baseCommit);current=paths(a.source)
assert set(current)-set(old)=={'lib/editor/wordlm/context-model.json','lib/editor/wordlm/context-info.json'}
assert not set(old)-set(current)
artifacts={}
for name in current:
 b=run('git','show',a.source+':'+name);assert b==Path(name).read_bytes(),name
 if name in old:assert b==run('git','show',baseCommit+':'+name),name
 artifacts[name]=sha(b)
assert artifacts['lib/editor/wordlm/context-model.json']==read(Path('lib/editor/wordlm/context-info.json'))['artifactSHA256']
a.out.mkdir(exist_ok=False)
with (a.out/'application-source.tar.gz').open('wb') as f:subprocess.run(['git','archive','--format=tar.gz',a.source],stdout=f,check=True)
for source,name in [(base,'baseline'),(root/'final-v8','final'),(root/'browser','browser'),(root/'comparison','comparison'),(root/'v8','matrix')]:
 target=a.out/name;target.mkdir()
 for item in source.iterdir():
  if item.is_file() and item.suffix in {'.gz','.json','.csv'}:shutil.copy2(item,target/item.name)
for name in ['WORK_LOG.md','package-final.py','save-artifact.py','original-240-traces.jsonl.gz','trace-original-240.ts','benchmark-whole-strategy.json','wordlm-browser-validation.json','punctcase-automatic-validation.json','live-worker-probe.ts','live-worker-verification.json','verify-remote.py','development-all7.log.gz','development-check8.log.gz']:
 shutil.copy2(root/name,a.out/name)
checks=a.out/'checks';checks.mkdir()
for path in sorted(Path('/tmp').glob('slothai-candidates-*8.log')):shutil.copy2(path,checks/path.name)
ciChecks=a.out/'checks'/'ci-artifacts';ciChecks.mkdir()
for item in sorted((root/'ci-download').rglob('*.json')):
 target=ciChecks/item.relative_to(root/'ci-download');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(item,target)
history=a.out/'development-summaries';history.mkdir()
for variant in range(1,9):
 source=root/('v'+str(variant))/'summary.json'
 if source.exists():shutil.copy2(source,history/('v'+str(variant)+'-summary.json'))
for name in ['ci-live-verification.json','final-model-usage.json','final-site-review.json','github-trained-context-receipt.json','final-verification.json']:
 shutil.copy2(root/name,a.out/name)
provenance={'applicationSourceCommit':a.source,'evaluatedBaseCommit':baseCommit,'runtimeSourceMatchesCommit':True,'runtimeSHA256':final['runtimeSHA256'],'originalRuntimeJSONUnchanged':True,'originalRuntimeJSONCount':len(old),'runtimeJSONSHA256':artifacts,'newRuntimeArtifacts':list(set(current)-set(old)),'corpusSHA256':final['corpusSHA256'],'goldReviewSHA256':final['goldReviewSHA256'],'reviewedTargetsSHA256':final['reviewedTargetsSHA256'],'finalResultsSHA256':final['resultsSHA256'],'browserResultsSHA256':browser['resultsSHA256'],'originalSixTrainingArchivesIncluded':False,'bulkPreparedTrainingDataIncluded':False}
(a.out/'RUN_PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
restore=f'''# Continue candidate correction work

Verify the outer SHA256SUMS, extract this archive, then run `sha256sum -c SHA256SUMS` inside it.
Clone https://github.com/Sanan2030/SlothAI and check out `{a.source}`. The exact source fallback is `application-source.tar.gz`.
Read `docs/qa/candidate-fixes-2026-11-05.md` in the source, comparison/summary.json and final-verification.json here.
Inputs/references are frozen; this assistant-authored compositional development set is not a blind or real-user accuracy benchmark.
Decompress COPIES of results.jsonl.gz with `gzip -dk` before using scripts/qa evaluation/comparison commands. Run Node evaluation into a fresh output directory, build/start the app, then browser-novel-10000.ts --require-automatic --legacy-false with Node results.
Both models run automatically. Source-only WordLM context counts supplement the original model; original17runtimeJSON weights are unchanged. This archive contains application-ready context counts and their script/receipts, NOT original source text. Retraining needs canonical train SHA b92e4edc6cb9eaaf214f35284cc8ec5e23acdb7763e40b281d8f0f9b9c9da8a9.
comparison/remaining-errors.jsonl.gz is the work queue; final/error-traces.jsonl.gz contains observed decisions; final-site-review.json groups the reviewed mechanisms and limits. Retain proper names, correct words, original references and existing training jobs.
CharSpell remains a separate unfinished training run. Do not promote partial weights or restart it blindly. Its rolling recoverable checkpoints, optimizer/RNG and status are at https://github.com/Sanan2030/SlothAI/releases/tag/charspell-backup-2026-11-04 ; inspect current reports before resuming.
Other recoveries: https://github.com/Sanan2030/SlothAI/releases/tag/wordlm-context-backup-2026-11-05 and https://github.com/Sanan2030/SlothAI/releases/tag/punctcase-backup-2026-11-04 .
Original6traininggzip and bulk prepared training data are excluded. Read WORK_LOG.md for rejected variants, provenance and validation scope. Never rewrite gold to fit model outputs.
'''
(a.out/'RESTORE.md').write_text(restore)
files=sorted(x for x in a.out.rglob('*') if x.is_file())
(a.out/'SHA256SUMS').write_text(''.join(sha(x.read_bytes())+'  '+str(x.relative_to(a.out))+'\n' for x in files))
archive=a.out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:t.add(a.out,arcname='candidate-fixes-recovery')
with tarfile.open(archive) as t:
 for line in t.extractfile('candidate-fixes-recovery/SHA256SUMS').read().decode().splitlines():
  h,name=line.split('  ',1);assert sha(t.extractfile('candidate-fixes-recovery/'+name).read())==h,name
print(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'innerFilesVerified':len(files),'sourceCommit':a.source},indent=2))
