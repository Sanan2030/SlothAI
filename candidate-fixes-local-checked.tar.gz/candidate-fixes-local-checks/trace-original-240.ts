import { readFileSync, writeFileSync } from 'node:fs';
import { gzipSync, gunzipSync } from 'node:zlib';
import { correctText, formatEmail } from '../../../lib/editor/correct';
import type { EditorDiagnostic } from '../../../lib/editor/diagnostics';
const root='artifacts/qa/candidate-fixes-20261105';
const rows=JSON.parse(readFileSync('artifacts/qa/candidate-audit-20261105/cases.json','utf8'));
const outputs=new Map(gunzipSync(readFileSync(root+'/v8/results.jsonl.gz')).toString().trim().split('\n').map(line=>JSON.parse(line)).filter(row=>row.set==='errors-240').map(row=>[row.id,row]));
const equal=(s:string)=>s.normalize('NFC').replace(/\s+/gu,' ').trim();
const records=rows.map((row:any)=>{
 const decisions:EditorDiagnostic[]=[];const runtime={diagnostics:(e:EditorDiagnostic)=>decisions.push(e)};
 const actual=row.module==='mail'?formatEmail(row.input,row.options,runtime).text:correctText(row.input,row.options.preserveFormatting,runtime).text;
 const saved:any=outputs.get(row.id);if(equal(actual)!==equal(saved.after))throw Error('Diagnostic replay differs: '+row.id);
 return {id:row.id,input:row.input,expected:row.expected,actual,fixed:saved.afterExact,decisions,scope:'Original frozen240 disagreements; diagnostic replay verified against app strategy results. Relative scores are not correctness probabilities.'};
});
writeFileSync(root+'/original-240-traces.jsonl.gz',gzipSync(records.map(r=>JSON.stringify(r)).join('\n')+'\n'));
console.log(JSON.stringify({cases:records.length,fixed:records.filter(r=>r.fixed).length}));
