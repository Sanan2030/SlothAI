"""Read-only exact-commit CI/deployment verification and authorized app probes."""
import argparse,json,subprocess,time,urllib.request
from pathlib import Path
from datetime import datetime,timezone
p=argparse.ArgumentParser();p.add_argument('--source',required=True);a=p.parse_args();repo='Sanan2030/SlothAI';root=Path('artifacts/qa/charspell-integration-20261106')
def run(*args):return subprocess.check_output(args,text=True,stderr=subprocess.PIPE,timeout=120)
def api(path):return json.loads(run('gh','api',path))
def save(name,value):(root/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
started=time.monotonic();ci=None;deployment=None;last=None
while time.monotonic()-started<1800:
 runs=json.loads(run('gh','run','list','--repo',repo,'--commit',a.source,'--workflow','performance.yml','--json','databaseId,headSha,status,conclusion,url','--limit','5'))
 ci=runs[0] if runs else None
 if ci and ci['status']=='completed':assert ci['conclusion']=='success',ci
 deployments=api('repos/'+repo+'/deployments?sha='+a.source+'&per_page=5')
 for d in deployments:
  assert d['sha']==a.source
  statuses=api('repos/'+repo+'/deployments/'+str(d['id'])+'/statuses')
  if statuses and statuses[0]['state']=='success':deployment={'id':d['id'],'sha':d['sha'],'status':statuses[0]};break
 state=(ci.get('status') if ci else 'pending','success' if deployment else 'pending')
 if state!=last:print(json.dumps({'ci':state[0],'deployment':state[1],'elapsedSeconds':round(time.monotonic()-started)}),flush=True);last=state
 if ci and ci['status']=='completed' and deployment:break
 time.sleep(15)
assert ci and ci['conclusion']=='success' and deployment,'CI/deployment did not complete'
trainingRuns=json.loads(run('gh','run','list','--repo',repo,'--commit',a.source,'--workflow','training-tools.yml','--json','databaseId,headSha,status,conclusion,url','--limit','5'))
assert trainingRuns and trainingRuns[0]['headSha']==a.source
trainingCI=trainingRuns[0]
if trainingCI['status']!='completed':
 run('gh','run','watch',str(trainingCI['databaseId']),'--repo',repo,'--exit-status','--interval','10')
 trainingCI=json.loads(run('gh','run','view',str(trainingCI['databaseId']),'--repo',repo,'--json','headSha,status,conclusion,url'))
assert trainingCI['conclusion']=='success',trainingCI

detail=json.loads(run('gh','run','view',str(ci['databaseId']),'--repo',repo,'--json','jobs,headSha,conclusion,url'))
assert detail['headSha']==a.source and detail['conclusion']=='success'
steps=[step for job in detail['jobs'] for step in job['steps']]
assert any(s['name']=='Enforce complete validation gate' and s['conclusion']=='success' for s in steps)
assert all(s['conclusion'] not in ['failure','cancelled'] for s in steps)
url=deployment['status']['environment_url'];checks=[]
for route in ['/api/health','/']:
 with urllib.request.urlopen(url+route,timeout=60) as r:
  body=r.read();assert r.status==200
  if route=='/':assert 'PunctCase — durğu və registr (sınaq)'.encode() not in body
  checks.append({'route':route,'passed':True,'http':200})
rows=[json.loads(line) for line in (root/'accepted-v13/results.jsonl').read_text().splitlines()]
ids={json.loads(line)['id'] for line in __import__('gzip').decompress((root/'original-153-traces.jsonl.gz').read_bytes()).decode().splitlines()}
row=next(r for r in rows if r['id'] in ids and r['mode']=='default' and r['module']=='text' and r['exact'] and r['metadata']['charSpell']['changedTokens']>0)
comma='Qeyd edək ki, bu məsələ hələ araşdırılır.'
cases=[('new-source-context','text-corrector',row['input'],row['options'],row['actual']),('punctcase-default','text-corrector','qeyd edək ki bu məsələ hələ araşdırılır',{},comma),('ignored-legacy-false','text-corrector','qeyd edək ki bu məsələ hələ araşdırılır',{'usePunctCase':False},comma),('mail-default','gmail-corrector','qeyd edək ki bu məsələ hələ araşdırılır',{'omitSubject':True},'Salam,\n\n'+comma+'\n\nHörmətlə,'),('protected-casing','text-corrector','GNU Linux PDF faylını saxlayır.',{},'GNU Linux PDF faylını saxlayır.'),('repeat','text-corrector',comma,{},comma)]
for name,strategy,text,options,expected in cases:
 request=urllib.request.Request(url+'/api/transform',data=json.dumps({'strategyId':strategy,'text':text,'options':options}).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(request,timeout=60) as r:result=json.load(r);assert r.status==200
 assert result['transformedText']==expected,(name,result)
 m=result['metadata'];assert all(m[k]['mode']=='automatic' and m[k]['loaded'] for k in ['wordLM','punctCase','charSpell'])
 assert m['wordLM']['sourceContextArtifactSHA256']=='5d7d592017ffa7417666d0a34f5ce472694befd35e146ba6ffbec45f44c295b4'
 assert m['charSpell']['sourceCheckpointSHA256']=='7d4338fc926023491d2d2f2c46196f7eb39af8bfad9134793e7ce596ba7e8ae3'
 if name=='new-source-context':assert m['charSpell']['rankedTokens']>0 and m['charSpell']['changedTokens']>0
 if name in ['punctcase-default','ignored-legacy-false','mail-default']:assert m['punctCase']['applied']>0
 checks.append({'case':name,'input':text,'expected':expected,'actual':result['transformedText'],'models':m,'passed':True})
worker=run('node','--import','tsx',str(root/'live-worker-probe.ts'),'--url='+url,'--source='+a.source)
save('ci-live-verification.json',{'atUTC':datetime.now(timezone.utc).isoformat(),'applicationCommit':a.source,'ci':detail,'trainingToolsCI':trainingCI,'deployment':deployment,'liveChecks':checks,'liveWorker':json.loads((root/'live-worker-verification.json').read_text())})
run('gh','run','download',str(ci['databaseId']),'--repo',repo,'--dir',str(root/'ci-download'))
print(json.dumps({'status':'verified','source':a.source,'ciURL':ci['url'],'deploymentURL':url,'liveAPIChecks':len(checks),'liveWorker':worker}),flush=True)
