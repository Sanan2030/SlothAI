import {chromium} from '@playwright/test';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
const arg=(key:string)=>process.argv.find(x=>x.startsWith('--'+key+'='))?.slice(key.length+3);
const root='artifacts/qa/charspell-integration-20261106';const url=arg('url');if(!url)throw Error('--url required');
async function main(){
 const cases=gunzipSync(readFileSync(root+'/v13/results.jsonl.gz')).toString().trim().split('\n').map(x=>JSON.parse(x));
 const row=cases.find(r=>r.set==='errors-153'&&r.metadata.strategyUsed==='text-corrector'&&r.afterExact&&r.metadata.charSpell.changedTokens>0);
 if(!row)throw Error('No verified new context repair case');
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 try{
  const page=await browser.newPage();let apiRequests=0;page.on('request',r=>{if(new URL(r.url()).pathname==='/api/transform')apiRequests++});
  await page.goto(url);if(await page.getByRole('checkbox',{name:/PunctCase/u}).count())throw Error('Activation control returned');
  const checks=[];
  for(const [input,expected] of [[row.input,row.after],['GNU Linux PDF faylını saxlayır.','GNU Linux PDF faylını saxlayır.']]){
   const box=page.getByRole('textbox',{name:'Xam mətn',exact:true});await box.fill(input);await page.getByRole('button',{name:'Düzəlt',exact:true}).click();
   await page.waitForFunction((expected)=>document.querySelector('.workspace-output pre')?.textContent===expected,expected,{timeout:60000});
   const log=await page.evaluate(()=>JSON.parse(localStorage.getItem('slothai-transform-log-v1')??'[]').at(-1));
   const m=log.modelUsage;
   if(![m.wordLM,m.punctCase,m.charSpell].every(x=>x.loaded&&x.mode==='automatic')||m.wordLM.sourceContextArtifactSHA256!=='5d7d592017ffa7417666d0a34f5ce472694befd35e146ba6ffbec45f44c295b4')throw Error('Wrong model version/activation');
   if(m.charSpell.sourceCheckpointSHA256!=='7d4338fc926023491d2d2f2c46196f7eb39af8bfad9134793e7ce596ba7e8ae3')throw Error('Wrong CharSpell checkpoint');
   if(input===row.input && !(m.charSpell.rankedTokens>0&&m.charSpell.changedTokens>0))throw Error('CharSpell not ranking repair');
   checks.push({input,expected,actual:await page.locator('.workspace-output pre').textContent(),models:m});
  }
  if(apiRequests||!page.workers().length)throw Error('Live UI did not use its editor Worker');
  const report={atUTC:new Date().toISOString(),url,sourceCommit:arg('source'),apiRequests,editorWorkerCount:page.workers().length,checks};
  writeFileSync(root+'/live-worker-verification.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:checks.length,url}));
 }finally{await browser.close()}
}
main().catch(e=>{console.error(e);process.exitCode=1});
