import {loadCharSpell} from '../../../lib/editor/charspell/load';
const scope=globalThis as any;
scope.onmessage=async(e:any)=>{try{const model=await loadCharSpell();scope.postMessage({rows:e.data.map((r:any)=>model.rank(r.input,r.candidates,r.left,r.right))});}catch(error){scope.postMessage({error:String(error)})}};
