import {build} from 'esbuild';import {chromium} from '@playwright/test';import {createServer} from 'node:http';import {readFileSync,writeFileSync} from 'node:fs';import {resolve} from 'node:path';import assert from 'node:assert/strict';
const root=resolve('artifacts/qa/charspell-integration-20261106');
await build({entryPoints:[root+'/parity-worker.ts'],outfile:root+'/parity-worker.js',bundle:true,format:'iife',platform:'browser',logLevel:'silent'});
const server=createServer((req,res)=>{if(req.url==='/worker.js'){res.setHeader('Content-Type','application/javascript');res.end(readFileSync(root+'/parity-worker.js'));}else{res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><title>Numerical parity harness</title></html>')}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{const page=await browser.newPage();await page.goto('http://127.0.0.1:'+server.address().port);
 const golden=JSON.parse(readFileSync('tests/fixtures/charspell-golden.json','utf8'));
 const response=await page.evaluate(rows=>new Promise((resolve,reject)=>{const worker=new Worker('/worker.js');worker.onmessage=e=>{resolve(e.data);worker.terminate()};worker.onerror=e=>reject(Error(e.message));worker.postMessage(rows)}),golden.examples);
 assert.ok(!response.error,response.error);let maximum=0,count=0;
 golden.examples.forEach((row,i)=>row.candidates.forEach((word,j)=>{maximum=Math.max(maximum,Math.abs(response.rows[i].find(x=>x.word===word).logit-row.logits[j]));count++}));
 assert.ok(maximum<golden.absoluteTolerance,String(maximum));
 const report={scope:'Actual Chromium Worker vs original PyTorch float32 checkpoint numerical parity; no quality or calibration claim',sourceCheckpointSHA256:golden.sourceCheckpointSHA256,examples:golden.examples.length,candidateLogits:count,maximumAbsoluteLogitDifference:maximum,absoluteTolerance:golden.absoluteTolerance,passed:true,browser:browser.version(),quantization:'none; original float32'};
 writeFileSync(root+'/charspell-browser-parity.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}finally{await browser.close();await new Promise(r=>server.close(r))}
