import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {getStrategyRegistry} from '../../../lib/strategies/bootstrap';
import type {EditorDiagnostic} from '../../../lib/editor/diagnostics';
const root='artifacts/qa/charspell-integration-20261106';
const equal=(s:string)=>s.normalize('NFC').replace(/\s+/gu,' ').trim();
async function main(){
 const originals=new Map(gunzipSync(readFileSync('artifacts/qa/candidate-fixes-20261105/comparison/remaining-errors.jsonl.gz')).toString().trim().split('\n').map(x=>JSON.parse(x)).filter(r=>r.mode==='default').map(r=>[r.id,r]));
 const rows=gunzipSync(readFileSync(root+'/v13/results.jsonl.gz')).toString().trim().split('\n').map(x=>JSON.parse(x)).filter(r=>r.set==='errors-153');
 const records=[];
 for(const row of rows){
  const decisions:EditorDiagnostic[]=[];
  const strategy=getStrategyRegistry().get(row.metadata.strategyUsed);
  const result=await strategy.transform({text:row.input,options:originals.get(row.id).options},{diagnostics:(event:EditorDiagnostic)=>decisions.push(event)});
  if(equal(result.transformedText)!==equal(row.after))throw Error('Diagnostic output differs: '+row.id);
  records.push({...row,actual:result.transformedText,decisions,metadata:result.metadata,scope:'Original frozen 153 disagreements, actual full app strategy with diagnostics. Relative candidate logits are not correctness probabilities; fixes include linguistic and pipeline changes.'});
 }
 writeFileSync(root+'/original-153-traces.jsonl.gz',gzipSync(records.map(r=>JSON.stringify(r)).join('\n')+'\n'));
 console.log(JSON.stringify({cases:records.length,fixed:records.filter(r=>equal(r.actual)===equal(r.expected)).length,diagnosticEvents:records.reduce((n,r)=>n+r.decisions.length,0)}));
}
main().catch(e=>{console.error(e);process.exitCode=1});
