import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';import {gunzipSync,gzipSync} from 'node:zlib';
import {getStrategyRegistry} from '../../../lib/strategies/bootstrap';
import {getStrategyRegistry as oldRegistry} from '/tmp/slothai-charspell-base/lib/strategies/bootstrap';
const root='artifacts/qa/charspell-integration-20261106';const label=process.argv.find(x=>x.startsWith('--label='))?.slice(8)??'v1';const out=root+'/'+label;mkdirSync(out,{recursive:false});
const equal=(s:string)=>s.normalize('NFC').replace(/\s+/gu,' ').trim();
async function main(){const summaries:any={};const records:any[]=[];
 const errors=gunzipSync(readFileSync('artifacts/qa/candidate-fixes-20261105/comparison/remaining-errors.jsonl.gz')).toString().trim().split('\n').map(x=>JSON.parse(x)).filter(r=>r.mode==='default');
 for(const [name,rows] of [['errors-153',errors],...['calibration-100','holdout-500','no-harm-2000'].map(n=>[n,JSON.parse(readFileSync('data/evaluation/phase0/'+n+'.json','utf8')).cases])] as any){
 const summary:any={cases:rows.length,beforeExact:0,afterExact:0,fixed:[],regressed:[],unstable:[],changed:[],exceptions:[]};
 for(const row of rows){
  const strategy=row.module==='mail'?'gmail-corrector':'text-corrector';const request={text:row.input,options:row.options};
  try{const before=row.after??(await oldRegistry().get(strategy).transform(request)).transformedText;
  const result=await getStrategyRegistry().get(strategy).transform(request);const after=result.transformedText;
  const repeated=(await getStrategyRegistry().get(strategy).transform({text:after,options:row.options})).transformedText;
  const oldOK=equal(before)===equal(row.expected),newOK=equal(after)===equal(row.expected);summary.beforeExact+=+oldOK;summary.afterExact+=+newOK;
  if(!oldOK&&newOK)summary.fixed.push(row.id);if(oldOK&&!newOK)summary.regressed.push(row.id);if(before!==after)summary.changed.push(row.id);if(after!==repeated)summary.unstable.push(row.id);
  records.push({set:name,id:row.id,input:row.input,expected:row.expected,before,after,repeated,beforeExact:oldOK,afterExact:newOK,metadata:result.metadata});
  }catch(e){summary.exceptions.push({id:row.id,error:String(e)});}
 }
 summaries[name]=summary;console.log(JSON.stringify({set:name,before:summary.beforeExact,after:summary.afterExact,regressed:summary.regressed,unstable:summary.unstable,exceptions:summary.exceptions}));
 }
 writeFileSync(out+'/summary.json',JSON.stringify(summaries,null,2)+'\n');writeFileSync(out+'/results.jsonl.gz',gzipSync(records.map(x=>JSON.stringify(x)).join('\n')+'\n'));
}
main().catch(e=>{console.error(e);process.exitCode=1});
