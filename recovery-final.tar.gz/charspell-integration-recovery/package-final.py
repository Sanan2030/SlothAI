"""Package the exact promoted application and verified recovery evidence."""
import argparse,gzip,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path('artifacts/qa/charspell-integration-20261106');base='cec79df940445506d6a0cd9369f216a432f92c74'
read=lambda p:json.loads(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
run=lambda *args:subprocess.check_output(args)
report=read(Path('docs/qa/charspell-integration-2026-11-06.summary.json'))
browser=read(root/'browser/summary.json');remote=read(root/'ci-live-verification.json')
assert remote['applicationCommit']==a.source and remote['ci']['conclusion']=='success' and remote['trainingToolsCI']['conclusion']=='success'
assert all(r['cases']==r['exact']==r['automaticModelRequests']==r['charSpellModelRequests']==10000 and r['exceptions']==r['nodeParityDifferences']==0 for r in browser['totals'].values())
assert browser['transformHTTPRequests']==0 and browser['requireCharSpell'] and browser['requireAutomatic']
for name,h in report['runtimeSHA256'].items():assert sha(run('git','show',a.source+':'+name))==h==sha(Path(name).read_bytes()),name
paths=lambda commit:[s for s in run('git','ls-tree','-r','--name-only',commit,'lib/editor','lib/strategies').decode().splitlines() if s.endswith('.json')]
old=paths(base);current=paths(a.source)
assert len(old)==19 and set(current)-set(old)=={'lib/editor/charspell/model-info.json','lib/editor/charspell/selection-policy.json','lib/editor/charspell/weights.json'}
assert not set(old)-set(current)
runtime={}
for name in current:
 b=run('git','show',a.source+':'+name);assert b==Path(name).read_bytes()
 if name in old:assert b==run('git','show',base+':'+name),name
 runtime[name]=sha(b)
assert report['nodeResultsSHA256']==sha((root/'accepted-v13/results.jsonl').read_bytes())
a.out.mkdir(exist_ok=False)
with (a.out/'application-source.tar.gz').open('wb') as f:subprocess.run(['git','archive','--format=tar.gz',a.source],stdout=f,check=True)
for source,name in [(Path('artifacts/qa/candidate-fixes-20261105/final-v8'),'baseline'),(root/'accepted-v13','final'),(root/'browser','browser'),(root/'comparison','comparison'),(root/'v13','matrix')]:
 target=a.out/name;target.mkdir()
 for item in source.iterdir():
  if item.is_file() and item.suffix in {'.gz','.json','.csv'}:shutil.copy2(item,target/item.name)
for name in ['WORK_LOG.md','package-final.py','check.ts','trace-original-153.ts','original-153-traces.jsonl.gz','repair-ledger-153.jsonl.gz','benchmark-whole-accepted.json','charspell-browser-parity.json','parity-browser.mjs','parity-worker.ts','live-worker-probe.ts','verify-remote.py','live-worker-verification.json','ci-live-verification.json','final-model-usage.json','github-export-receipt.json','final-verification.json']:
 shutil.copy2(root/name,a.out/name)
shutil.copy2(Path('artifacts/qa/candidate-fixes-20261105/save-artifact.py'),a.out/'save-artifact.py')
shutil.copy2(Path('artifacts/training/sessions/20261104-charspell/charspell-full/report.json'),a.out/'charspell-completed-training-report.json')
checks=a.out/'checks';checks.mkdir()
for path in sorted(Path('/tmp').glob('slothai-charspell-*.log')):
 if any(label in path.name for label in ['accepted','training-contracts','audit','data','remote','trace']):shutil.copy2(path,checks/path.name)
ciChecks=checks/'ci-artifacts';ciChecks.mkdir()
for item in sorted((root/'ci-download').rglob('*.json')):
 target=ciChecks/item.relative_to(root/'ci-download');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(item,target)
history=a.out/'development-summaries';history.mkdir()
for label in [*('v'+str(i) for i in range(1,14)),'attempt-9981']:
 source=root/label/'summary.json'
 if source.exists():shutil.copy2(source,history/(label+'.json'))
provenance={'applicationSourceCommit':a.source,'evaluatedBaseCommit':base,'runtimeSourceMatchesCommit':True,'runtimeSHA256':report['runtimeSHA256'],'originalRuntimeJSONUnchanged':True,'originalRuntimeJSONCount':19,'runtimeJSONSHA256':runtime,'newRuntimeArtifacts':sorted(set(current)-set(old)),'corpusSHA256':report['corpusSHA256'],'goldReviewSHA256':report['goldReviewSHA256'],'reviewedTargetsSHA256':report['reviewedTargetsSHA256'],'nodeResultsSHA256':report['nodeResultsSHA256'],'browserResultsSHA256':browser['resultsSHA256'],'originalSixTrainingArchivesIncluded':False,'bulkPreparedTrainingDataIncluded':False,'charSpellWeightsRetrainedOnQA':False}
(a.out/'RUN_PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
restore=f'''# Continue from the completed CharSpell integration

Verify the outer SHA256SUMS, extract the archive, then run `sha256sum -c SHA256SUMS` inside it.
Clone https://github.com/Sanan2030/SlothAI and check out `{a.source}`. The exact fallback source is application-source.tar.gz.
Read docs/qa/charspell-integration-2026-11-06.md and docs/training/charspell-app-2026-11-06.md in that source, plus final-verification.json, RUN_PROVENANCE.json and WORK_LOG.md here.
All three application models run automatically in text/mail. CharSpell training is COMPLETE (4 epochs, selected 2), not a partial run. The browser uses all original 21,857 float32 parameters from checkpoint SHA7d4338fc926023491d2d2f2c46196f7eb39af8bfad9134793e7ce596ba7e8ae3. No new training is required to run the app.
Original 19 runtime JSON artifacts remain byte-identical to the previous main. The only new three JSON are CharSpell model-info, selection-policy and weights. Runtime file hashes match the exact promoted source.
The original153 disagreements are fixed with0regressions;10,000/10,000 development matches in both modes. This authored corpus has been used for development, is not blind or real-user accuracy, and its approved references were not changed. The 2,000 no-harm examples remain correct. Eight pre-existing test TODO remain; zero test failures. Separate holdout397/500 remains imperfect.
repair-ledger-153.jsonl.gz records every original disagreement, before/after, options, observed decision reasons and model receipts. original-153-traces.jsonl.gz records the actual full-strategy diagnostic replay; comparisons use NFC/whitespace. Candidate logits are not calibrated correctness probabilities. Improvements include morphology, lexical relations and pipeline ordering, not only neural CharSpell changes. No sentence-ID runtime lookup or QA weight fitting.
For QA, decompress COPIES of results.jsonl.gz (`gzip -dk`). Run Node scripts/qa/evaluate-novel-10000.ts into a fresh directory, build/start the application, then scripts/qa/browser-novel-10000.ts with --require-automatic --require-charspell --legacy-false and those Node results. Never rewrite gold to fit outputs. Read recorded CI/live receipts before claiming deployment status.
The original completed CharSpell training checkpoint, optimizer/RNG and last state are at https://github.com/Sanan2030/SlothAI/releases/tag/charspell-backup-2026-11-04 . Browser export/parity recovery is https://github.com/Sanan2030/SlothAI/releases/tag/charspell-browser-backup-2026-11-06 . Other models: wordlm-context-backup-2026-11-05 and punctcase-backup-2026-11-04 releases. Preserve these original checkpoints.
The original six training gzip archives and bulk prepared data are EXCLUDED. Training/re-export needs the accepted canonical source receipt; inference only needs committed app artifacts. Do not restart training blindly or publish/reapply cloud configuration.
'''
(a.out/'RESTORE.md').write_text(restore)
files=sorted(x for x in a.out.rglob('*') if x.is_file());(a.out/'SHA256SUMS').write_text(''.join(sha(x.read_bytes())+'  '+str(x.relative_to(a.out))+'\n' for x in files))
archive=a.out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:t.add(a.out,arcname='charspell-integration-recovery')
with tarfile.open(archive) as t:
 for line in t.extractfile('charspell-integration-recovery/SHA256SUMS').read().decode().splitlines():
  h,name=line.split('  ',1);assert sha(t.extractfile('charspell-integration-recovery/'+name).read())==h,name
print(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'innerFilesVerified':len(files),'sourceCommit':a.source},indent=2))
