import argparse,gzip,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',required=True);a=p.parse_args();r=Path('artifacts/qa/corporate-100k-20261106');out=r/'recovery-final'
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();run=lambda *args:subprocess.check_output(args)
s=read(r/'summary.json');m=read(Path('data/qa/corporate-100k-2026-11-06/MANIFEST.json'));source=read(r/'node/RUN_SOURCE.json');ci=read(r/'measured-application-ci.json')
assert ci['headSha']==source['sourceCommit']==m['sourceCommit']==s['sourceCommit'] and ci['conclusion']=='success'
assert any(v['name']=='Enforce complete validation gate' and v['conclusion']=='success' for j in ci['jobs'] for v in j['steps'])
for path,h in source['runtimeSHA256'].items():assert sha(Path(path).read_bytes())==h==sha(run('git','show',a.source+':'+path)),path
for path,h in read(r/'GENERATED_DATA.json').items():assert sha(Path(path).read_bytes())==h,path
assert s['primaryRequests']==1000 and s['inputWords']==100000 and s['correct']==297 and s['incorrect']==703 and s['technicalErrors']==0 and s['physicalTransformationCalls']==3001
assert s['strictReferenceMatches']==264 and s['acceptedCorrectConditionalCommaRepairs']==33
assert sha(gzip.decompress((r/'adjudicated-results.jsonl.gz').read_bytes()))==s['adjudicatedResultsSHA256']
assert sha(gzip.decompress((r/'errors.jsonl.gz').read_bytes()))==s['errorsSHA256']
assert sha(gzip.decompress(Path('data/qa/corporate-100k-2026-11-06/cases.jsonl.gz').read_bytes()))==m['corpusSHA256']
assert sha(Path('scripts/qa/build-corporate-100k.py').read_bytes())==m['generatorSHA256']
assert sha(Path('scripts/qa/corporate-100k-pools.txt').read_bytes())==m['authoredPoolsSHA256']
assert read(r/'frozen-audit.json')['passed'] and read(r/'report-verification.json')['passed']
changes=run('git','diff','--name-only',m['sourceCommit'],a.source).decode().splitlines();assert all(path.startswith(('scripts/qa/','data/qa/corporate-100k-2026-11-06/','docs/qa/')) for path in changes)
out.mkdir(exist_ok=False)
with (out/'application-and-audit-source.tar.gz').open('wb') as f:subprocess.run(['git','archive','--format=tar.gz',a.source],stdout=f,check=True)
for name in ['node','browser','browser-ui-recheck','browser-accepted']:
 target=out/name;target.mkdir()
 for item in (r/name).iterdir():
  if item.is_file() and item.suffix in {'.gz','.json','.jsonl'}:shutil.copy2(item,target/item.name)
for item in r.iterdir():
 if item.is_file() and item.suffix in {'.json','.gz','.csv','.html','.md','.py','.mjs'} and item.name!='recovery-final.tar.gz':shutil.copy2(item,out/item.name)
corpus=out/'frozen-corpus';corpus.mkdir()
for name in ['MANIFEST.json','cases.jsonl.gz']:shutil.copy2(Path('data/qa/corporate-100k-2026-11-06')/name,corpus/name)
generated=out/'generated-dictionary';generated.mkdir()
for name in ['az-words.json','az-stem-classes.json']:shutil.copy2(Path('lib/editor/generated')/name,generated/name)
for name in ['corporate-100k-2026-11-06.md','corporate-100k-2026-11-06.summary.json','corporate-100k-2026-11-06.adjudication.json']:shutil.copy2(Path('docs/qa')/name,out/name)
checks=out/'checks';checks.mkdir()
for path in Path('/tmp').glob('slothai-corporate-100k-*.log'):shutil.copy2(path,checks/path.name)
restore=f'''# Restore the corporate 100,000-word application audit

Verify outer SHA256SUMS, extract, then run `sha256sum -c SHA256SUMS` inside the archive.
The published audit/source commit is `{a.source}`; application-and-audit-source.tar.gz is the exact source fallback. The measured application is `{m['sourceCommit']}`. All145runtimefiles are byte-identical, verified against both commits. No app/model/threshold changes or training were performed.
Read corporate-100k-2026-11-06.md, summary.json, ADJUDICATION_POLICY.json and WORK_LOG.md. Open report.html offline or all-results.csv (UTF-8 BOM) for every input/reference/output/verdict. Detailed ledgers: adjudicated-results.jsonl.gz and errors.jsonl.gz.
Primary test:1000uniquecompositionalrequests,exact100000inputwords,16corporatedomains,700text/300mail. Assistant authorized to judge correctness:297correct,703withatleastoneerror,0technicalfailures. Strictfrozen-reference264plus33correctconditionalcommarepairs. Corpuscontainsoneauthoredmissingconditionalcomma repeatedin100cases; originalinputs/goldneverrewritten, judgmenterratumisexplicit. Blocksrepeatwithintheset; not1000independentreal-userobservations. Noveltyvs19092pinnedpriorQArefs:noexactor8wordoverlap.
Request accounting:1000primarycases,1000Nodecomparisoncalls,1000Noderepeatcalls,plus1configuredUIrecheck=3001physicalwholetransformations. Initialbrowser1000containsonegreeting-optionmismatch,notamodeldifference; the originalattemptisretained. browser-accepted combinescorrectfirstUIrecheckwith999matchingoriginalWorkeroutputs. Final1000byte-paritywithNode,all3automatic,0HTTPtransforms. ThiswasoneUIclickplus999postsintothatUI-createdWorker,not1000DOMclicks. Sourceprobesandrawresponses are included.
Each incorrect output has a primary category and reason:433spelling/inflection,111wrongcontextword,148punctuation/boundary,11case. Seven first outputs change on repeat, allsevenfirstpassincorrect. Do not substitute improvedsecondpassesintotheprimaryscore. Literal250casesallpreserved. Of184unambiguouslycorrectinputs43damaged; other16of200identityinputscontainthereferencecommaomission. Char38048positions78248candidates,PCase1proposal/applied. Loaded and useful are different facts.
Replay: clone/check out the source commit, `npm ci`, `npm run dictionary:import -- public/dictionaries/az`. Saved generated-dictionary files are hash-bound fallbacks for lib/editor/generated if needed. Run `node --import tsx scripts/qa/evaluate-corporate-100k.mjs --out=artifacts/qa/corporate-new/node` into a fresh directory. Build/start the app, then browser-corporate-100k.mjs with --node/--out/--url. Correctly set Salamlaşma=Salam, in any manual UI comparison. New output differences need fresh linguistic review; existing adjudication findings bind this frozen output, not arbitrary future models.
Historical novelty auditor audit-frozen.py expects measuredHEAD4e0028c. Later audit publication commits contain this corpus and would self-match. For historical verification use a4echeckout with copied corpus/tools/receipts, or read the pinned4eGitarchive; do not weaken novelty thresholds. Keep the frozen cases instead of regenerating or relabeling them to improve scores.
Measured application CI42208198650 passed all steps including final complete validation gate. Publication-only CI status, if present, is separately recorded; an in-progress snapshot must not be claimed completed.
Originalsixuploadedtraininggzipandbulkpreparedtrainingdata are EXCLUDED. Runtime inference needs the committed models and generated dictionary, not the raw corpus. Model/checkpoint recovery remains https://github.com/Sanan2030/SlothAI/releases/tag/charspell-integration-2026-11-06 . Do not restart training blindly or train on this evaluation corpus. No cloud configuration was reapplied or published.
'''
(out/'RESTORE.md').write_text(restore)
provenance={'publishedAuditCommit':a.source,'measuredApplicationCommit':m['sourceCommit'],'runtimeFilesVerified':len(source['runtimeSHA256']),'runtimeSHA256':source['runtimeSHA256'],'corpusSHA256':m['corpusSHA256'],'adjudicatedResultsSHA256':s['adjudicatedResultsSHA256'],'primaryRequests':1000,'inputWords':100000,'physicalTransformationCalls':3001,'correct':297,'incorrect':703,'technicalErrors':0,'inputOrGoldRewritten':False,'appOrWeightsChanged':False,'trainingPerformed':False,'originalSixUploadedTrainingGzipIncluded':False,'bulkPreparedTrainingDataIncluded':False,'changedFilesSinceMeasuredApplication':changes}
(out/'RUN_PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
files=sorted(path for path in out.rglob('*') if path.is_file());(out/'SHA256SUMS').write_text(''.join(sha(path.read_bytes())+'  '+str(path.relative_to(out))+'\n' for path in files));archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:t.add(out,arcname='corporate-100k-recovery')
with tarfile.open(archive) as t:
 for line in t.extractfile('corporate-100k-recovery/SHA256SUMS').read().decode().splitlines():
  h,name=line.split('  ',1);assert sha(t.extractfile('corporate-100k-recovery/'+name).read())==h,name
print(json.dumps({'source':a.source,'archive':str(archive),'archiveSHA256':sha(archive.read_bytes()),'innerFilesVerified':len(files),'primaryRequests':1000,'inputWords':100000,'physicalTransformationCalls':3001},indent=2))
