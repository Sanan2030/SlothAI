from pathlib import Path
import gzip,hashlib,json,runpy,subprocess
r=Path('data/qa/corporate-100k-2026-11-06');m=json.loads((r/'MANIFEST.json').read_text());helper=runpy.run_path('scripts/qa/build-corporate-100k.py');raw=gzip.decompress((r/'cases.jsonl.gz').read_bytes());rows=list(map(json.loads,raw.decode().splitlines()));assert helper['sha'](raw)==m['corpusSHA256'];assert helper['sha'](Path('scripts/qa/corporate-100k-pools.txt').read_bytes())==m['authoredPoolsSHA256'];assert helper['sha'](Path('scripts/qa/build-corporate-100k.py').read_bytes())==m['generatorSHA256']
commit,old,refs,tri,eight,index,files=helper['legacy']();assert commit==m['sourceCommit'] and files==m['previousQA']['files'];assert helper['sha']('\n'.join(old).encode())==m['previousQA']['referenceSHA256']
maximum=0
for row in rows:
 assert helper['count'](row['input'])==row['inputWords'];assert len(row['input'])<10000
 for text in [row['input'],row['authoredBody']]:
  ok,score,why=helper['novelty'](text,refs,tri,eight,index);assert ok,(row['id'],why);maximum=max(maximum,score)
assert len(rows)==1000 and sum(row['inputWords'] for row in rows)==100000
assert len(set(row['input'] for row in rows))==1000 and len(set(helper['normalized'](row['authoredBody']) for row in rows))==1000
source=json.loads(Path('artifacts/qa/corporate-100k-20261106/node/RUN_SOURCE.json').read_text())
for p,h in source['runtimeSHA256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
j={'passed':True,'requests':1000,'inputWords':100000,'uniqueInputs':1000,'uniqueNormalizedBodies':1000,'previousNormalizedReferences':len(old),'previousExactOverlap':0,'sharedPreviousEightWordSequences':0,'maximumTrigramJaccard':maximum,'authoredPoolsAndGeneratorUnchanged':True,'runtimeFilesUnchanged':len(source['runtimeSHA256']),'sourceCommit':commit}
Path('artifacts/qa/corporate-100k-20261106/frozen-audit.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j))
