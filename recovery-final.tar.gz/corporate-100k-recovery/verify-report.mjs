import {chromium} from '@playwright/test';
import {readFileSync,writeFileSync} from 'node:fs';
const root='artifacts/qa/corporate-100k-20261106';const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{
 const page=await browser.newPage({viewport:{width:1280,height:950}});let requests=0;const errors=[];page.on('request',()=>requests++);page.on('pageerror',e=>errors.push(String(e)));
 await page.setContent(readFileSync(root+'/report.html','utf8'));
 if(await page.locator('#matched').textContent()!=='1000 nəticə')throw Error('Incomplete cases');
 await page.locator('#verdict').selectOption('correct');if(await page.locator('#matched').textContent()!=='297 nəticə')throw Error('Wrong correct count');
 await page.locator('#verdict').selectOption('incorrect');if(await page.locator('#matched').textContent()!=='703 nəticə')throw Error('Wrong error count');
 await page.locator('#verdict').selectOption('');await page.locator('#domain').selectOption('finance');if(await page.locator('#matched').textContent()!=='63 nəticə')throw Error('Domain filter wrong');
 await page.locator('#domain').selectOption('');await page.locator('#search').fill('corp100k-0005');if(!(await page.locator('#actual').textContent()).includes('ötürüləcək. Məlumatlar'))throw Error('Missing actual evidence');
 await page.locator('#search').fill('');await page.screenshot({path:root+'/report-desktop.png',fullPage:true,animations:'disabled'});
 await page.setViewportSize({width:390,height:844});if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Mobile horizontal overflow');await page.screenshot({path:root+'/report-mobile.png',fullPage:true,animations:'disabled'});
 if(requests||errors.length)throw Error(JSON.stringify({requests,errors}));
 writeFileSync(root+'/report-verification.json',JSON.stringify({passed:true,all1000casesPresent:true,correctFilter:297,incorrectFilter:703,domainFilter63:true,actualExampleVerified:true,networkRequests:requests,pageErrors:errors,mobileOverflow:false,browser:browser.version()},null,2)+'\n');console.log('Offline report1000cases,297/703filters,actualevidence,0network/mobileoverflow passed.');
}finally{await browser.close()}
