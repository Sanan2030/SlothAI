import argparse,gzip,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',required=True);a=p.parse_args();root=Path('artifacts/qa/model-contributions-20261106');out=root/'recovery-final'
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();run=lambda *args:subprocess.check_output(args)
m=read(root/'MANIFEST.json');report=read(Path('docs/qa/model-contributions-2026-11-06.summary.json'));ci=read(root/'ci-verification.json');measuredCI=read(root/'measured-application-ci.json')
assert ci['headSha']==a.source and ci['conclusion'] not in ['failure','cancelled']
assert measuredCI['headSha']==m['sourceCommit'] and measuredCI['conclusion']=='success'
assert any(s['name']=='Enforce complete validation gate' and s['conclusion']=='success' for j in measuredCI['jobs'] for s in j['steps'])
assert all(s['conclusion'] not in ['failure','cancelled'] for j in measuredCI['jobs'] for s in j['steps'])
changed=run('git','diff','--name-only',m['sourceCommit'],a.source).decode().splitlines()
assert all(p.startswith(('scripts/qa/','docs/qa/','data/evaluation/model-contributions/')) for p in changed)
for path,h in m['runtimeSHA256'].items():assert sha(run('git','show',a.source+':'+path))==sha(Path(path).read_bytes())==h,path
variants=[*report['variants'],'w0lexc1p1'];requests=0
for variant in variants:
 summary=read(root/variant/'summary.json');raw=gzip.decompress((root/variant/'results.jsonl.gz').read_bytes());assert sha(raw)==summary['resultsSHA256'];assert len(raw.splitlines())==12976;assert all(t['exceptions']==0 for t in summary['totals'].values());requests+=len(raw.splitlines())
assert requests==116784 and report['wordLMDecisionSourceRemoval']['sets']['development-10000']['improved']==964
for path,h in m['sourceFilesSHA256'].items():assert sha(Path(path).read_bytes())==h,path
assert read(root/'html-verification.json')['passed'] and report['actualAppParity']['passed']
out.mkdir(exist_ok=False)
with (out/'application-and-study-source.tar.gz').open('wb') as f:subprocess.run(['git','archive','--format=tar.gz',a.source],stdout=f,check=True)
for variant in variants:
 target=out/variant;target.mkdir()
 for name in ['summary.json','results.jsonl.gz']:shutil.copy2(root/variant/name,target/name)
for source in root.iterdir():
 if source.is_file() and source.suffix in {'.json','.gz','.md','.mjs','.py'} and source.name not in ['recovery-final.tar.gz']:
  shutil.copy2(source,out/source.name)
receipts=out/'bundle-recipes';receipts.mkdir()
for path in (root/'bundles').glob('*.receipt.json'):shutil.copy2(path,receipts/path.name)
checks=out/'checks';checks.mkdir()
for path in Path('/tmp').glob('slothai-model-*.log'):
 if path.stat().st_size<2_000_000:shutil.copy2(path,checks/path.name)
for name in ['model-contributions-2026-11-06.html','model-contributions-2026-11-06.md','model-contributions-2026-11-06.summary.json']:shutil.copy2(Path('docs/qa')/name,out/name)
restore=f'''# Restore the completed model contribution study

Verify outer SHA256SUMS, extract the archive, then run `sha256sum -c SHA256SUMS` inside it.
Clone https://github.com/Sanan2030/SlothAI and check out `{a.source}`; application-and-study-source.tar.gz is the exact fallback.
Measured application source is {m['sourceCommit']}; all132runtimefiles match this report/tooling commit byte-for-byte. Application and model weights/policies were NOT changed. All3models stay automatic in production.
Read model-contributions-2026-11-06.md, summary JSON and the offline HTML. Read WORK_LOG.md before using exploratory results. The accepted learned-data-only WordLM contribution is964developmentcases, NOT the rejected1044broadhelper-removal experiment. WordLM score-only32, Char8 and PCase0 on10k; separate500sample Wscore1/Char1/PCase0;40contrastPCase3. Conditional contributions overlap; never add them. Char9differences allsurətfamily,8samecontinuation. This is authored development data, not real-user accuracy or a blind evaluation.
Measured application7c577ea has completed successful Production validation including finalcompletegate (measured-application-ci.json). Report/tooling4e0028c changes only7report/tooling/diagnostic-fixture files; its new fullCI may still be running in ci-verification.json. Check https://github.com/Sanan2030/SlothAI/actions/runs/42208198650 for current status; do NOT interpret an in-progress snapshot as a completed gate. Local lint/types/HTML/paireddata checks are complete. Runtime parity and hashes prove the measured app code itself is unchanged.
Nine accepted configurations each12976cases give116784primaryrequests,0exceptions; results and inputs are gzipped JSONL. The 8factorialvariants keep trained WordLM lexical data fixed; w0lexc1p1 removes ONLY the trained word list in lexical-evidence plus its probability/context decisions, leaving helper bodies/general dictionary repairs intact. Final document monitor remains and does not affect outputs. All older models/rules/morphology remain; w0c0p0 is not model-free.
Full app parity:10000publishedoutputs +2976freshstrategycalls, exactbytes. Eight score variants' changed outputs are stable. Extra lexical-data-off variant has49unstable changed outputs,0full-app unstable in paired checks. Fixed2000noharm passes in everyvariant;40newcontrasts full34/40include onecorrectinput hurt byoldpunctuationrules.
Remaining103holdoutdocuments/105worderrors:89targets already inWordLMvocab butonly2inappcandidatepool. Post-audit source1editprototype retrieves89; Char43top1/84top3, existingfusion12top1/81top3. These are diagnosis results, NOT deployed improvements. Expected words are never injected into retrieval. Do not train on these holdout/QA references or tune thresholds to match them. PCaseinsert-onlypolicy prevents removal of an observed wrong comma; raising/lowering a weight alone is not a complete fix.
Run `npm ci` and `npm run dictionary:import -- public/dictionaries/az`, then the fresh-output commands in the Markdown report. Original frozen cases.jsonl.gz and MANIFEST.json here reproduce exactpairedinputs. INPUT_ALIASES.json maps the original40-probe workspace path to the committed byte-identical fixture; no input/reference changed. Recompute new results into a FRESH --out directory; do not overwrite this recovery.
Source files and per-bundle onLoad patch receipts explain every ablation. Bundled JS is deliberately excluded (large generated copies); rebuild it with scripts/qa/model-contributions.mjs. SHA256 and full per-request outputs are included.
Complete app/model/checkpoint recoveries remain https://github.com/Sanan2030/SlothAI/releases/tag/charspell-integration-2026-11-06 and charspell-backup-2026-11-04. Original6traininggzip and bulk preparedtrainingdata are EXCLUDED. No cloud configuration was reapplied or published.
'''
(out/'RESTORE.md').write_text(restore)
provenance={'publishedStudyCommit':a.source,'measuredAppCommit':m['sourceCommit'],'runtimeSourceMatchesBothCommits':True,'runtimeFiles':len(m['runtimeSHA256']),'runtimeSHA256':m['runtimeSHA256'],'casesSHA256':m['casesSHA256'],'acceptedConfigurations':9,'acceptedPrimaryRequests':requests,'measuredApplicationCI':'success including final gate','reportToolingCIStatusAtSave':ci['status'],'reportToolingCIConclusionAtSave':ci['conclusion'],'changedFilesSinceMeasuredApplication':changed,'appOrWeightChanges':False,'referenceChanges':False,'originalSixTrainingArchivesIncluded':False,'bulkPreparedTrainingDataIncluded':False}
(out/'RUN_PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
files=sorted(path for path in out.rglob('*') if path.is_file());(out/'SHA256SUMS').write_text(''.join(sha(path.read_bytes())+'  '+str(path.relative_to(out))+'\n' for path in files))
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:t.add(out,arcname='model-contributions-recovery')
with tarfile.open(archive) as t:
 for line in t.extractfile('model-contributions-recovery/SHA256SUMS').read().decode().splitlines():
  h,name=line.split('  ',1);assert sha(t.extractfile('model-contributions-recovery/'+name).read())==h,name
print(json.dumps({'source':a.source,'archive':str(archive),'archiveSHA256':sha(archive.read_bytes()),'innerFilesVerified':len(files),'requests':requests},indent=2))
