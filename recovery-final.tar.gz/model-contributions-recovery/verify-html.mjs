import {chromium} from '@playwright/test';
import {readFileSync,writeFileSync} from 'node:fs';
const root='artifacts/qa/model-contributions-20261106';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{
 const page=await browser.newPage({viewport:{width:1280,height:960}});let networkRequests=0;const errors=[];
 page.on('request',()=>networkRequests++);page.on('pageerror',e=>errors.push(String(e)));
 await page.setContent(readFileSync('docs/qa/model-contributions-2026-11-06.html','utf8'));
 const check=async(expected)=>{if(await page.locator('#exact').textContent()!==expected)throw Error('Wrong displayed score: '+await page.locator('#exact').textContent())};
 await check('10000 / 10000');await page.locator('#w').uncheck();await check('9968 / 10000');
 await page.locator('#c').uncheck();await check('9968 / 10000');
 await page.locator('#dataset').selectOption('punctuation-contrasts-40');await check('34 / 40');
 await page.locator('#p').uncheck();await check('31 / 40');
 await page.locator('#w').check();await page.locator('#c').check();await page.locator('#p').check();
 await page.locator('#dataset').selectOption('holdout-500');await check('397 / 500');
 await page.locator('#dataset').selectOption('development-10000');await check('10000 / 10000');
 if(!(await page.locator('#lexical').textContent()).includes('9036'))throw Error('Stale WordLM lexical score');
 if(networkRequests||errors.length)throw Error(JSON.stringify({networkRequests,errors}));
 await page.screenshot({path:root+'/report-desktop.png',fullPage:true,animations:'disabled'});
 await page.setViewportSize({width:390,height:844});if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Mobile overflow');
 await page.screenshot({path:root+'/report-mobile.png',fullPage:true,animations:'disabled'});
 writeFileSync(root+'/html-verification.json',JSON.stringify({passed:true,scoreAssertions:7,wordLMLexical9036Verified:true,networkRequests,errors,mobileOverflow:false,browser:browser.version()},null,2)+'\n');
 console.log('Offline HTML seven score states, final964 attribution, mobile layout and0networkrequests verified.');
}finally{await browser.close()}
