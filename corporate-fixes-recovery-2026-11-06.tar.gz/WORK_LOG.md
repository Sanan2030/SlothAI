# Corporate correction recovery

Application source: `b5bf4080918a99ee4e405bb9d6f77515f3f0a423`. The frozen corporate corpus has 1000 requests and exactly 100000 input words. The original297 correct outputs remain correct. 528of703previous failures are fixed;825correct,175still fail. See review-release/report.html, all-results.csv and remaining-errors.jsonl.gz. Do not claim all failures were repaired or that this synthetic development score is general accuracy.

The original two approved conditional reference omissions are explicit in ADJUDICATION_POLICY.json. Inputs and gold are unchanged. Strict exact669;156valid reference-comma repairs accepted. All200identity inputs are correct. Two incorrect outputs still change on repeat; never replace first-pass results in the headline score. All250literal cases preserved.

Models: allthree automatic, original22JSONfiles byte-identical. No new CharSpell/WordLM/PunctCase checkpoint was promoted. Legacy synthetic artifacts were retrained only in an isolated checkout for byte-reproduction checks; logs are included. Do not train on this QA corpus or on the175remaining assistant-authored targets. The six uploaded raw gzip files and bulk prepared training data are excluded.

Earlier complete model/checkpoint recovery: https://github.com/Sanan2030/SlothAI/releases/tag/charspell-integration-2026-11-06 . The earlier corporate baseline is https://github.com/Sanan2030/SlothAI/releases/tag/corporate-100k-2026-11-06 .

User-provided artifacts/architecture files were preserved and never included in the source commit. Root README retains its final dot. Cloud configuration was not published or reapplied.

Final forensic diagnostic ledger covers all175remaining outputs and is byte-matched to production. For150word-differencegroups,119correctforms are present in recorded candidate pools but not chosen,23are absent from recorded pools,and8have no corresponding recorded candidate event. Missing events are not proof that no earlier stage ever generated that form. See remaining-diagnostic-ledger.jsonl.gz and trace-remaining.jsonl.gz.
